# Chapter 15: Building Your Automation Stack

## How Tools Connect — And Where to Start

By now you've seen 12 different automation playbooks. Each one works on its own, but the real power comes when you connect them into a system.

This chapter shows you how to think about your automation stack — which tools to choose, how they fit together, and what order to build in.

---

## The Three Layers of an Automation Stack

Think of your automation stack as three layers:

### Layer 1: AI Tools (The Brains)
These do the thinking — drafting emails, summarizing documents, scoring leads.

| Tool | Price | Best For |
|------|-------|----------|
| ChatGPT (Free) | €0 | General text tasks, drafting, brainstorming |
| ChatGPT Plus | €20/mo | Faster responses, file uploads, advanced analysis |
| Claude | €0-20/mo | Long documents, nuanced writing, analysis |
| Google Gemini | €0-20/mo | Google Workspace integration, research |
| Microsoft Copilot | €30/user/mo | Office 365 integration |

**Start here.** Pick one AI tool your team is comfortable with. Don't spread across three — consistency beats variety.

### Layer 2: Automation Platforms (The Connectors)
These move data between tools automatically — "when X happens, do Y."

| Tool | Price | Best For |
|------|-------|----------|
| Zapier | €0-20/mo | Beginners, widest app support (6,000+) |
| Make.com | €0-9/mo | Visual workflows, more complex logic |
| Power Automate | Included with Microsoft 365 | Microsoft ecosystem |
| n8n | €0 (self-hosted) | Technical teams, full control |
| IFTTT | €0-3/mo | Simple triggers, IoT devices |

**Add this second.** Once you have 2-3 manual AI workflows running, automate the triggers and handoffs.

### Layer 3: Specialized Tools (The Specialists)
These handle specific jobs better than general AI.

| Category | Free Option | Paid Option |
|----------|------------|-------------|
| Meeting notes | Google Docs + AI | Otter.ai (€8/mo), Fireflies.ai (€10/mo) |
| Social media | Buffer free tier | Buffer (€5/mo), Hootsuite (€19/mo) |
| Email marketing | MailerLite free | MailerLite paid (€9/mo) |
| Document processing | ChatGPT uploads | DocuSign, Adobe Acrobat AI |
| Accounting | Wave (free) | QuickBooks (€12/mo), Xero (€15/mo) |
| CRM | HubSpot free | HubSpot Starter (€15/mo) |
| Help desk | Freshdesk free | Zendesk (€19/agent/mo) |

**Add these last** — only when the free/general approach isn't cutting it for a specific workflow.

---

## Recommended Stacks by Budget

### The €0 Stack (Pure Free Tier)
- **AI:** ChatGPT free or Claude free
- **Automation:** Zapier free (5 zaps) or Make.com free (1,000 ops)
- **Email:** MailerLite free
- **CRM:** HubSpot free
- **Meetings:** Google Meet + manual AI summary
- **Social:** Buffer free

**Best for:** Solo operators and micro-businesses testing the waters.

**Limitations:** Manual triggers, limited automation runs, slower AI responses.

### The €50/month Stack (Best Value)
- **AI:** ChatGPT Plus (€20/mo)
- **Automation:** Zapier Starter (€20/mo) or Make.com Basic (€9/mo)
- **Email:** MailerLite Growing (€9/mo)
- **Everything else:** Free tiers

**Best for:** Small teams (2-10 people) ready to commit. This covers 80% of automation needs.

### The €150/month Stack (Full Power)
- **AI:** ChatGPT Plus + Claude Pro (€40/mo)
- **Automation:** Zapier Professional (€50/mo)
- **Meetings:** Otter.ai Business (€17/mo)
- **Social:** Buffer Essentials (€5/mo)
- **CRM:** HubSpot Starter (€15/mo)
- **Email:** MailerLite Growing (€9/mo)
- **Accounting:** QuickBooks (€12/mo)

**Best for:** Teams of 10-50 with multiple departments automating simultaneously.

---

## Integration Priorities — What to Connect First

Not all connections are equal. Here's the order that delivers the most value:

### Priority 1: Email → CRM (Week 1)
When someone emails you, their details should automatically appear in your CRM. When you send a follow-up, it should be logged.

**Why first:** This is where leads and revenue live. Every missed follow-up is money lost.

### Priority 2: Calendar → Meeting Notes (Week 2)
When a meeting ends, notes should be generated and shared automatically.

**Why second:** This saves time every single day and improves team accountability.

### Priority 3: Forms/Website → Email Marketing (Week 3)
When someone signs up on your website, they should enter your email funnel automatically.

**Why third:** This is your growth engine. Manual follow-up doesn't scale.

### Priority 4: Social Media → Scheduling (Week 4)
Batch-create content, schedule it, and let it run. Stop posting manually every day.

**Why fourth:** Time savings compound — 30 minutes saved daily is 10+ hours per month.

### Priority 5: Finance → Reporting (Month 2)
Automate expense categorization, invoice processing, and monthly reports.

**Why fifth:** Important but not urgent. The first four priorities drive revenue and save daily time.

---

## The Integration Map

Here's how a typical SME automation stack connects:

```
Website/Forms
    ↓
Email Marketing (MailerLite) ←→ CRM (HubSpot)
    ↓                              ↓
Lead Scoring (AI)          Sales Follow-up (AI)
    ↓                              ↓
Qualified Lead Alert        Email Sequence
    ↓
Sales Team (Slack/Email notification)

Calendar Events
    ↓
Meeting Recording
    ↓
AI Transcription + Notes
    ↓
Action Items → Task Manager

Content Creation (AI)
    ↓
Scheduling (Buffer)
    ↓
Social Platforms (LinkedIn, X, Facebook)

Receipts/Invoices
    ↓
AI Processing
    ↓
Accounting Software
    ↓
Monthly Reports (AI-generated)
```

---

## Common Mistakes

### 1. Buying Too Many Tools at Once
Start with one or two automations working perfectly. Then expand. Most failed automation projects tried to do everything simultaneously.

### 2. Not Documenting Your Workflows
When you build an automation, write down what it does, what triggers it, and what happens if it fails. Future you (or your team) will thank you.

### 3. Ignoring Error Handling
Every automation will eventually fail — an API goes down, a format changes, a field is empty. Build in notifications for failures so they don't silently break.

### 4. Choosing Tools Your Team Won't Use
The best tool is the one people actually use. If your team lives in Google Workspace, don't force Microsoft tools. Meet them where they are.

### 5. Over-Automating
Not everything should be automated. If a process happens once a month and takes 10 minutes, the time to set up and maintain automation isn't worth it. Focus on daily and weekly tasks.

---

## Your Action Plan

1. **List your current tools** — What does your team already use daily?
2. **Pick one AI tool** — Standardize on ChatGPT, Claude, or Gemini
3. **Start with the €0 stack** — Free tiers only until you prove value
4. **Build one automation per week** — Using the playbooks in this guide
5. **Upgrade tools only when free tiers limit you** — Let usage drive spending, not excitement

---

## Key Takeaway

Your automation stack should grow organically. Start simple, prove value, then invest. The companies that succeed with automation aren't the ones with the most tools — they're the ones who use fewer tools consistently well.

---

*Next: Chapter 16 — Measuring and Improving Your Automations →*
