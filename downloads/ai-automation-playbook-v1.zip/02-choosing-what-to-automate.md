# Chapter 2: Choosing What to Automate First

## The Biggest Mistake: Automating the Wrong Thing

You're excited about AI automation. You've read Chapter 1. You understand the layers. Now comes the question that makes or breaks your automation journey:

**Which task do you automate first?**

Get this right, and you'll save real time within a week, build confidence, and gain momentum. Get it wrong, and you'll spend two weeks on something that saves 15 minutes a month — and wonder why everyone says AI is overhyped.

This chapter gives you a dead-simple scoring system to find your best automation candidates, plus the common mistakes that trip up first-timers.

---

## The Effort/Impact/Risk (EIR) Scoring System

Every task you're considering automating can be scored on three dimensions:

### Impact: How Much Time and Value Will This Save?

Score from 1 to 5:

| Score | Meaning | Example |
|-------|---------|---------|
| 1 | Saves less than 30 minutes per week | Formatting a single weekly report |
| 2 | Saves 30 min–1 hour per week | Sorting incoming emails into folders |
| 3 | Saves 1–3 hours per week | Drafting responses to common customer questions |
| 4 | Saves 3–5 hours per week | Processing invoices and entering data |
| 5 | Saves 5+ hours per week OR unlocks new capability | Qualifying all inbound leads automatically |

**Don't just count hours.** A task that saves 1 hour but eliminates a constant source of frustration for your team might deserve a higher impact score. A task that currently doesn't get done at all (like following up with every lead) gets a high score because automation enables something new.

### Effort: How Hard Is It to Set Up?

Score from 1 to 5 (here, **lower is better** — less effort is more attractive):

| Score | Meaning | Example |
|-------|---------|---------|
| 1 | Under 1 hour, free tools, copy-paste prompts | Using ChatGPT to draft email replies |
| 2 | 1–3 hours, free tools, some configuration | Building a FAQ from existing documents |
| 3 | 3–8 hours, might need a paid tool, some integration | Setting up Otter.ai for meeting transcription |
| 4 | 1–2 days, paid tools required, workflow changes | Connecting invoice scanning to accounting software |
| 5 | Multiple days, custom development or complex integration | Building a custom AI chatbot on your website |

### Risk: What Happens If the AI Gets It Wrong?

Score from 1 to 5 (again, **lower is better** — less risk is more attractive):

| Score | Meaning | Example |
|-------|---------|---------|
| 1 | No real consequences, easily caught and fixed | Internal meeting summary has a typo |
| 2 | Minor inconvenience, quick to correct | Draft email needs editing before sending |
| 3 | Could annoy a customer or cause rework | Wrong category on an invoice |
| 4 | Could lose money or damage a relationship | Incorrect lead score causes bad follow-up |
| 5 | Legal, financial, or reputational harm | Auto-approved contract with bad terms |

---

## How to Calculate Your Priority Score

For each task, calculate:

**Priority Score = Impact − (Effort × 0.5) − (Risk × 0.5)**

The higher the score, the better the candidate for your first automation.

**Why the formula works:**
- High impact pushes the score up (you want big wins)
- High effort pulls it down (you want quick wins)
- High risk pulls it down (you want safe wins)
- Effort and risk are weighted at 0.5 because a very impactful task can justify some effort and some risk

---

## Scoring Template

Copy this template and fill it in for your top 5-10 repetitive tasks:

```
AUTOMATION PRIORITY SCORECARD
=============================

Task: ________________________________
Who does it now: _____________________
How often: ___________________________
Time spent per week: _________________

SCORING (circle one for each):

Impact (1-5):      1    2    3    4    5
Effort (1-5):      1    2    3    4    5
Risk (1-5):        1    2    3    4    5

Priority Score = Impact - (Effort × 0.5) - (Risk × 0.5)
              = ____ - (____ × 0.5) - (____ × 0.5)
              = ________

NOTES:
- Current pain point: ________________________
- What would AI-assisted version look like: ________________________
- First step to test: ________________________
```

---

## Worked Example: Scoring Four Tasks

Let's say you run a 15-person services company and you're considering automating these tasks:

### Task 1: Customer Email Responses
- **Impact:** 4 (saves 3-5 hours/week across the team)
- **Effort:** 1 (copy-paste prompts into ChatGPT, under an hour to set up)
- **Risk:** 2 (human reviews before sending)
- **Priority Score:** 4 − 0.5 − 1.0 = **2.5** ✅ Great candidate

### Task 2: Meeting Notes & Action Items
- **Impact:** 3 (saves 1-2 hours/week, reduces forgotten action items)
- **Effort:** 2 (need to set up a transcription tool, train the team)
- **Risk:** 1 (internal use only, mistakes are harmless)
- **Priority Score:** 3 − 1.0 − 0.5 = **1.5** ✅ Good candidate

### Task 3: Invoice Processing
- **Impact:** 3 (saves 2-3 hours/week)
- **Effort:** 4 (need paid tools, accounting software integration)
- **Risk:** 3 (wrong numbers could cause accounting errors)
- **Priority Score:** 3 − 2.0 − 1.5 = **−0.5** ⚠️ Not a great first project

### Task 4: Website Chatbot
- **Impact:** 3 (could handle after-hours inquiries)
- **Effort:** 5 (custom development, needs training data, ongoing maintenance)
- **Risk:** 4 (customer-facing with no human review)
- **Priority Score:** 3 − 2.5 − 2.0 = **−1.5** ❌ Save this for later

**Winner:** Customer email responses — highest score, lowest effort, manageable risk with human review.

---

## How to Prioritize: The 4-Step Process

### Step 1: Brain Dump (15 minutes)

Write down every repetitive task in your business. Don't filter — just list. Ask your team:
- "What task do you dread most?"
- "What do you spend time on that feels like it could be automated?"
- "What falls through the cracks because nobody has time?"

Aim for 10-20 tasks. Here are common categories to prompt your thinking:
- Email and communication
- Data entry and processing
- Scheduling and follow-ups
- Report creation
- Research and information gathering
- Customer support
- Content creation
- Document handling

### Step 2: Score Each Task (20 minutes)

Use the EIR scoring template for each task. Be honest — don't inflate impact scores because you're excited about a particular automation.

### Step 3: Rank by Priority Score (5 minutes)

Sort your tasks from highest to lowest priority score. Your first automation project is the task at the top of the list.

### Step 4: Start with ONE (important!)

Pick the single highest-scoring task and commit to implementing it this week. Do not start three automations simultaneously. Here's why:

- You need to learn the rhythm of testing and refining prompts
- Your team needs to adjust to working with AI on one process before adding more
- If something goes wrong, you want to know which automation caused it
- Quick wins build momentum; juggling multiple projects builds frustration

After you've had your first automation running smoothly for 2-3 weeks, move to the next one on your list.

---

## Common Mistakes When Choosing What to Automate

### Mistake 1: Automating What's Exciting Instead of What's Impactful

"Let's build an AI chatbot on our website!" sounds cool. But if your team spends 4 hours a day on email and your website gets 20 visitors a day, the chatbot is a vanity project. Automate email first.

**Fix:** Always start with the EIR score, not your gut feeling.

### Mistake 2: Starting with the Hardest Task

Some business owners think "If AI can handle the hard stuff, it can handle everything." So they try to automate their most complex process first, fail, and conclude AI doesn't work.

**Fix:** Start with something simple. Your first win should be easy to achieve. Build from there.

### Mistake 3: Automating a Broken Process

If your current process is chaotic, inconsistent, or undocumented, automating it will just create automated chaos. AI is excellent at doing predictable things faster — it's terrible at fixing your broken workflows.

**Fix:** If you can't write down the steps for a process on one page, document and simplify it first, then automate.

### Mistake 4: Ignoring the "Who Does This Now?" Question

If only one person does a task and they're fine with it, automating might create resistance instead of relief. If a task is spread across the team and everyone hates it, automation will be welcomed with open arms.

**Fix:** Talk to the people who do the work. Their buy-in matters more than your spreadsheet says.

### Mistake 5: Optimizing for Full Automation Too Early

The goal of your first project is NOT full automation. It's AI-assisted automation — saving time while keeping a human in the loop. Full automation is Layer 3. You're building to Layer 2.

**Fix:** Re-read Chapter 1. Move one layer at a time.

### Mistake 6: Not Tracking Time Before and After

If you don't know how long a task takes now, you can't prove your automation saved time. Without proof, it's hard to justify expanding to more automations.

**Fix:** Before you automate anything, have the person doing the task track their time for one week. After automation, track again. Simple before/after comparison.

---

## Your Action Plan

Before moving to the playbook chapters, do this:

1. **Spend 15 minutes** listing every repetitive task in your business
2. **Score your top 10** using the EIR template
3. **Pick #1** — the highest-scoring task
4. **Flip to the matching playbook chapter** and implement it this week

If your top-scoring task matches one of our playbooks (Chapters 3-7), you're in luck — we've done the work of writing step-by-step instructions for you. If it doesn't match exactly, the framework still applies: start with AI-assisted, use the prompts as templates, and iterate.

---

## Quick Reference: Which Playbook Chapter to Use

| Your Top Task | Go To |
|---------------|-------|
| Responding to customer emails | Chapter 3 |
| Building a FAQ or knowledge base | Chapter 4 |
| Qualifying or scoring leads | Chapter 5 |
| Meeting notes and action items | Chapter 6 |
| Processing invoices, receipts, or contracts | Chapter 7 |

Let's get to the playbooks.
