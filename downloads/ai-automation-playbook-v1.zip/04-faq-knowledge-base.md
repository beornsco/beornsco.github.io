# Chapter 4: FAQ & Knowledge Base Builder

## What This Playbook Does

Every company has "tribal knowledge" — the stuff that lives in people's heads, old email threads, and scattered documents. When someone leaves or is on vacation, that knowledge disappears.

This playbook shows you how to use AI to extract that tribal knowledge and turn it into a structured FAQ or knowledge base that your team (and optionally your customers) can search and use. Instead of spending days writing documentation from scratch, you'll use AI to do the heavy lifting while you review and organize.

**Estimated implementation time:** 4-6 hours (spread across a few days)
**Expected time savings:** 2-4 hours per week (fewer repeated questions, faster onboarding)
**Difficulty:** Beginner to Intermediate

---

## Tools You'll Need

### Free Options
- **ChatGPT or Claude** — for transforming raw information into clean FAQ entries
- **Google Docs or Notion** (free tier) — for hosting and organizing the knowledge base
- **A simple spreadsheet** — for tracking question categories

### Paid Options (for a more polished, searchable experience)
- **Notion AI** ($10/member/month) — AI-powered search and auto-suggestions within your knowledge base
- **Slite** (from $8/member/month) — designed for internal knowledge bases with AI search
- **Helpjuice** (from $120/month) — customer-facing knowledge base with analytics
- **Guru** (from $15/user/month) — knowledge management with AI-powered answers
- **GitBook** (free for personal use, from $8/month for teams) — clean documentation with AI search

**Start free.** A well-organized Google Doc or Notion page beats an expensive tool with no content.

---

## Step-by-Step Setup

### Step 1: Identify Your Knowledge Sources (30 minutes)

Before building anything, figure out where your tribal knowledge currently lives. Common sources:

- **People's heads** — The most common and most dangerous source. Key employees who "just know" how things work.
- **Email threads** — Past customer questions and answers that were never documented.
- **Slack/Teams messages** — Answers buried in chat history.
- **Old documents** — SOPs, training manuals, product specs that exist but are outdated or hard to find.
- **Customer support tickets** — Patterns in what customers ask repeatedly.
- **Meeting notes** — Decisions and explanations from past meetings.

Make a list of your sources. For each one, note:
- What type of knowledge it contains
- How accessible it is (easy to export? need to ask someone?)
- How current it is

### Step 2: Collect the Raw Material (1-2 hours)

Now gather the actual content. You don't need to organize it yet — just collect.

**For knowledge in people's heads:**

Record a 15-20 minute "knowledge dump" conversation with each key person. You can use your phone's voice recorder or a tool like Otter.ai. Ask them:

> **Knowledge Dump Interview Questions:**
>
> 1. What are the top 10 questions you get asked by [customers/new employees/teammates]?
> 2. For each question, what's your standard answer?
> 3. What do people get wrong most often?
> 4. What's the process for [key workflow]? Walk me through it step by step.
> 5. Are there any unwritten rules or "gotchas" that people need to know?
> 6. What do you wish someone had told you when you started?

**For email/chat/ticket sources:**

Export or copy-paste the most relevant conversations. Focus on:
- Questions that come up at least monthly
- Answers that take more than 2 minutes to explain
- Anything where the answer has changed recently

**For existing documents:**

Gather them in one folder. Don't worry if they're outdated — we'll have AI help identify what needs updating.

### Step 3: Use AI to Generate FAQ Entries (1-2 hours)

Now take your raw material and feed it to AI to create structured FAQ entries. This is where the magic happens — AI is exceptionally good at turning messy notes into clean, organized answers.

> **FAQ Generation Prompt:**
>
> I'm building a knowledge base for my company. Below is raw information from [source — e.g., "an interview with our operations manager" / "customer support emails" / "our old policy documents"].
>
> Please:
> 1. Identify all distinct questions that this content answers (or implies)
> 2. For each question, write a clear, concise answer (3-7 sentences)
> 3. Group related questions into categories
> 4. Flag any information that seems contradictory or outdated
> 5. Write in plain language that a [new employee / customer — pick one] would understand
>
> Raw content:
> ---
> [Paste your raw notes, transcript, or document here]
> ---

**For large documents that won't fit in one prompt:**

> **Chunked FAQ Prompt:**
>
> I'm building a knowledge base. I'll share content in chunks. For this chunk, extract all FAQ-worthy questions and answers. Format each as:
>
> **Q: [Question]**
> **A: [Answer in 3-7 sentences]**
> **Category: [Suggested category]**
>
> Content chunk [X of Y]:
> ---
> [Paste chunk here]
> ---

### Step 4: Review and Edit the AI Output (1 hour)

AI will produce draft FAQ entries. Now you need to review them for:

**Accuracy:** Is the information correct? AI might misinterpret something from the raw material.

**Completeness:** Did it miss any important questions? Add ones you know are frequently asked.

**Tone:** Does it match how your company communicates? If it's too formal or too casual, adjust.

**Currency:** Is the information up to date? Mark anything that needs verification.

> **FAQ Review Prompt:**
>
> Here are draft FAQ entries for my company's knowledge base. Please review them and:
>
> 1. Identify any answers that sound vague or incomplete
> 2. Suggest additional questions that are commonly related to these topics
> 3. Simplify any answers that are longer than necessary
> 4. Point out any potential contradictions between entries
>
> [Paste your FAQ entries]

### Step 5: Organize into Categories (30 minutes)

Group your FAQ entries into logical categories. Common structures:

**For an internal knowledge base (employee-facing):**
- Getting Started / Onboarding
- Products & Services
- Policies & Procedures
- Tools & Systems
- Customer Handling
- Troubleshooting

**For a customer-facing FAQ:**
- Orders & Shipping
- Returns & Refunds
- Product Information
- Account & Billing
- Technical Support
- General Questions

Create your structure first, then slot each FAQ entry into the right category. If an entry fits multiple categories, put it in the most intuitive one and add a cross-reference.

### Step 6: Build the Knowledge Base (30-60 minutes)

Now put it all together in your chosen tool.

**If using Google Docs (simplest):**
- Create one document per category
- Use headings for each question (makes them searchable with Ctrl+F)
- Add a "Table of Contents" document that links to each category
- Share with your team via a shared drive

**If using Notion (recommended for growing teams):**
- Create a "Knowledge Base" page
- Use Notion's toggle blocks for Q&A format (question as toggle header, answer inside)
- Use Notion's database feature if you want to tag entries and filter by category
- Enable Notion AI search so team members can ask questions in natural language

**If using a dedicated tool (Slite, Helpjuice, etc.):**
- Follow the tool's setup wizard
- Import your organized content
- Configure search and navigation
- Set up access permissions

### Step 7: Fill Gaps with AI (30 minutes)

Look at your knowledge base and identify gaps. Use AI to help draft entries for missing topics:

> **Gap-Filling Prompt:**
>
> My company's knowledge base covers these categories: [list categories]
>
> For the category "[category name]", we currently have answers for:
> [List existing questions]
>
> What other questions would [employees / customers] commonly have in this category? For each suggested question, write a clear answer based on this context about our company:
>
> [Brief company description and relevant policies]

### Step 8: Set Up a Maintenance Routine (15 minutes)

A knowledge base that isn't updated becomes dangerous — people trust outdated information. Set up a simple maintenance process:

1. **Assign an owner** — one person responsible for the knowledge base (even if others contribute)
2. **Monthly review** — spend 30 minutes each month checking for outdated entries
3. **Feedback channel** — create a simple way for people to flag incorrect or missing information (a Slack channel, an email alias, or a form)
4. **Update trigger** — whenever a policy, process, or product changes, update the knowledge base as part of the change process

> **Monthly Review Prompt:**
>
> Here are our current knowledge base entries for [category]. Our company has recently [describe any changes — new policies, products, tools, etc.].
>
> Please review these entries and:
> 1. Flag any that might be outdated based on the changes described
> 2. Suggest updates to affected entries
> 3. Identify any new questions that should be added given the changes
>
> Current entries:
> [Paste entries]

---

## Example: Before and After

### Before (Tribal Knowledge Scattered):
- New employee asks "What's our return policy?" — has to find someone who knows
- Customer emails asking about bulk orders — gets forwarded between 3 people before someone answers
- Operations manager goes on vacation — nobody knows the supplier reorder process
- Same questions get asked and answered weekly in Slack

### After (AI-Built Knowledge Base):
- New employee searches the knowledge base → finds the answer in 30 seconds
- Customer-facing FAQ handles 60% of common questions before they become emails
- Supplier process is documented step-by-step → anyone can follow it
- Slack question → "Check the knowledge base" → answer found → 2 minutes instead of 20

---

## Expected Results

| Metric | Before | After |
|--------|--------|-------|
| Time to answer a common internal question | 5-15 minutes (find the right person, ask, wait) | 1-2 minutes (search the knowledge base) |
| New employee onboarding time | Days of shadowing and asking questions | Hours of reading + targeted questions only |
| Repeated questions in Slack/email per week | 10-20 | 2-5 (for things not yet documented) |
| Risk of knowledge loss when someone leaves | High | Low |
| Weekly time savings | — | 2-4 hours across the team |

---

## Common Pitfalls and How to Avoid Them

### Pitfall 1: Building It and Not Telling Anyone
The best knowledge base is useless if people don't know it exists. **Prevention:** Announce it. Demo it in a team meeting. Pin the link in Slack. Make it the first thing new employees see. When someone asks a question that's in the KB, reply with the link.

### Pitfall 2: Trying to Document Everything at Once
You don't need 200 entries on day one. **Prevention:** Start with your top 20-30 questions. Add more over time as gaps become obvious.

### Pitfall 3: AI-Generated Content That Nobody Verified
AI drafts are good starting points, but they might contain inaccuracies. **Prevention:** Have the subject matter expert review every entry before it goes live. Mark unverified entries clearly.

### Pitfall 4: The Knowledge Base Gets Stale
Within 3 months, some information will be outdated. **Prevention:** Monthly review routine (Step 8). Consider adding a "Last verified" date to each entry.

### Pitfall 5: Making It Too Formal or Complex
If the language is too corporate or the structure too complex, people won't use it. **Prevention:** Write like you talk. Use the same terminology your team uses. Keep answers short and scannable.

---

## Scaling Up: AI-Powered Search and Chatbot

Once your knowledge base has 50+ entries and is being actively used, consider these upgrades:

- **Notion AI** — lets team members type questions in natural language and get answers from your KB content
- **Custom ChatGPT GPT** — upload your KB as a file and create a custom GPT that answers questions based solely on your documentation
- **Intercom or Zendesk AI** — customer-facing chatbot that answers questions from your KB before routing to a human

> **Custom GPT Setup Prompt:**
>
> You are a knowledge base assistant for [Company Name]. Answer questions using ONLY the information in the uploaded document. If the answer isn't in the document, say "I don't have that information in our knowledge base — please contact [person/team] at [email]."
>
> Be concise. Quote relevant sections when helpful. If a question is ambiguous, ask for clarification.

---

## Quick-Start Checklist

- [ ] List all sources of tribal knowledge in your company
- [ ] Schedule 2-3 "knowledge dump" interviews with key people
- [ ] Collect raw material (transcripts, emails, documents)
- [ ] Use AI to generate draft FAQ entries
- [ ] Review and verify all entries for accuracy
- [ ] Organize into categories
- [ ] Build the knowledge base in your chosen tool
- [ ] Fill gaps with AI-assisted drafting
- [ ] Share with your team and demonstrate how to use it
- [ ] Set up a monthly review routine
- [ ] Track reduction in repeated questions
