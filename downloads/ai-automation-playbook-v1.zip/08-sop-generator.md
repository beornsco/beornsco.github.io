# Chapter 8: SOP Generator — Turn Tribal Knowledge into Standard Operating Procedures

## What This Playbook Does

Every business runs on unwritten rules. The way Sarah handles returns. The exact steps Marco follows when onboarding a new client. The workaround Dave uses when the inventory system glitches. This knowledge lives in people's heads — and when those people go on holiday, call in sick, or leave the company, the knowledge walks out the door with them.

This playbook shows you how to capture those informal processes and use AI to transform them into clean, professional Standard Operating Procedures (SOPs) that anyone on your team can follow.

**Time to implement:** 2–4 hours for your first SOP, then 30–60 minutes each after that.

**Expected time savings:** 3–5 hours per SOP (compared to writing them manually from scratch).

**Tools needed:**
- Any voice recording app (free — your phone's built-in recorder works)
- A transcription tool: Otter.ai (free tier), Google Docs voice typing (free), or Whisper (free, open source)
- An AI assistant: ChatGPT (free tier works), Claude, or any capable LLM
- A document editor: Google Docs, Word, or Notion (all have free options)

---

## Why Most SOPs Never Get Written

Let's be honest: nobody enjoys writing SOPs. The people who know the process are too busy doing it. The people who could write it up don't understand the process deeply enough. And the result is either:

1. No documentation at all (most common)
2. A document written once and never updated
3. A 47-page manual nobody reads

AI changes this equation completely. Instead of sitting down and writing from scratch, you simply **talk through what you do** and let AI structure it into a professional SOP. The bottleneck — turning messy knowledge into clean documentation — is exactly what AI excels at.

---

## Step-by-Step Process

### Step 1: Identify Your Most Critical Undocumented Process (15 minutes)

Don't try to document everything at once. Start with the process that causes the most pain when the person who knows it is unavailable.

**Ask yourself:**
- Which process would grind to a halt if one specific person were out for a week?
- What do new hires struggle with most in their first month?
- Which task generates the most "how do I do this again?" questions?
- Where do mistakes happen most often?

Pick one. Write down its name and who currently owns it.

### Step 2: Record the Process Owner Talking Through It (15–30 minutes)

This is the most important step, and it's deliberately low-effort. Don't ask anyone to write anything. Just ask them to talk.

**Set up the recording:**
Open your phone's voice recorder (or Otter.ai for automatic transcription). Tell the process owner:

> "I'm going to ask you to walk me through [process name] as if you're training someone brand new. Don't worry about being organized or polished — just explain it the way you'd explain it to a new hire sitting next to you. I'll record it so we don't have to do this again."

**Guide the conversation with these prompts:**
1. "What triggers this process? How do you know it's time to start?"
2. "Walk me through it from the very first step."
3. "What tools or systems do you use?"
4. "What do you do when [common problem] happens?"
5. "What mistakes do people usually make?"
6. "Is there anything you check or double-check before you consider it done?"
7. "How long does this usually take?"
8. "Is there anything you wish you'd known when you first learned this?"

**Pro tip:** Record screen shares when the process involves software. Tools like Loom (free tier) or your OS's built-in screen recorder capture both voice and visual steps.

### Step 3: Get a Transcript (5–15 minutes)

If you used Otter.ai, you already have one. Otherwise:

**Option A — Google Docs (free):**
Open a new Google Doc → Tools → Voice Typing → play the recording near your microphone. Not perfect, but workable.

**Option B — Whisper (free, more accurate):**
If you're slightly technical, OpenAI's Whisper gives excellent results. Many free web interfaces exist (search "whisper transcription free online").

**Option C — Paid transcription:**
Rev.com, Descript, or Otter.ai's paid tier all produce high-quality transcripts for $0.10–$0.25/minute.

Don't worry about transcript quality. Typos and odd formatting are fine — AI handles messy input well.

### Step 4: Feed the Transcript to AI and Generate a Draft SOP (10 minutes)

This is where the magic happens. Use this prompt:

> **Prompt — SOP Generator (First Draft)**
>
> You are a technical writer specializing in creating Standard Operating Procedures for small businesses.
>
> Below is a transcript of an employee describing how they perform [PROCESS NAME]. Please transform this into a professional SOP document with the following structure:
>
> 1. **Title** — Clear name for the procedure
> 2. **Purpose** — One paragraph explaining why this process exists and what it achieves
> 3. **Scope** — Who this applies to and when
> 4. **Prerequisites** — What's needed before starting (tools, access, information)
> 5. **Definitions** — Any terms or jargon that need explanation
> 6. **Step-by-Step Procedure** — Numbered steps, written as clear instructions. Each step should start with an action verb. Include sub-steps where needed. Note any decision points ("If X, do Y. If Z, do W.")
> 7. **Common Issues & Troubleshooting** — Problems that come up and how to handle them
> 8. **Quality Checks** — How to verify the process was completed correctly
> 9. **Time Estimate** — How long this typically takes
> 10. **Related Processes** — Any connected procedures
>
> Write at a level that a new employee with no prior experience could follow. Be specific — include exact button names, menu paths, and field names where mentioned. Flag any steps that seem unclear or where the transcript was ambiguous with [NEEDS CLARIFICATION].
>
> Here is the transcript:
> [PASTE TRANSCRIPT]

### Step 5: Review and Refine with AI (15–30 minutes)

The first draft will be 70–80% there. Now refine it:

**Fill in the gaps:**

> **Prompt — Gap Analysis**
>
> Review the SOP you just created. List any steps that might be confusing to a brand-new employee, any missing context, or any places where you had to guess what the speaker meant. Format as a numbered list of questions I should ask the process owner.

Take those questions back to the process owner. This usually takes 5 minutes — much easier than asking them to review a whole document.

**Add warnings and tips:**

> **Prompt — Add Practical Warnings**
>
> Review this SOP and add:
> - ⚠️ WARNING boxes before any step where a mistake could cause data loss, financial impact, or customer issues
> - 💡 TIP boxes where there's a faster way to do something or a helpful shortcut
> - ✅ CHECKPOINT boxes at natural pause points where the user should verify they're on track before continuing
>
> [PASTE CURRENT SOP]

**Simplify the language:**

> **Prompt — Readability Check**
>
> Rewrite this SOP so it scores below grade 8 on the Flesch-Kincaid readability scale. Replace any jargon with plain language. Keep all technical terms that are necessary but add brief definitions in parentheses.
>
> [PASTE CURRENT SOP]

### Step 6: Have Someone Test It (30–60 minutes)

This step is non-negotiable. Find someone who has never performed the process and ask them to follow the SOP step by step. Sit nearby (or have them share their screen) and note:

- Where they hesitate
- Where they ask questions
- Where they make a wrong turn
- Where they skip ahead because a step seems obvious

Every hesitation is a gap in your SOP. Feed the notes back to AI:

> **Prompt — Incorporate Tester Feedback**
>
> A new employee tested this SOP. Here are the issues they encountered:
>
> [LIST ISSUES]
>
> Please update the SOP to address each issue. Add clarifying details, reorder steps if needed, and make sure the problem areas are crystal clear.
>
> [PASTE CURRENT SOP]

### Step 7: Format and Publish (15 minutes)

Your SOP is now solid. Add final formatting:

> **Prompt — Final Formatting**
>
> Format this SOP for professional use with the following metadata header:
>
> - Document ID: [DEPARTMENT]-SOP-[NUMBER]
> - Version: 1.0
> - Created: [TODAY'S DATE]
> - Last Reviewed: [TODAY'S DATE]
> - Next Review: [DATE + 6 MONTHS]
> - Owner: [PROCESS OWNER NAME]
> - Approved By: [YOUR NAME]
>
> Also add a version history table at the bottom.
>
> [PASTE FINAL SOP]

Save it wherever your team can access it — Google Drive, Notion, SharePoint, or even a shared folder.

---

## Scaling Up: Building Your SOP Library

Once you've done one, the process gets much faster. Here's how to build momentum:

**Week 1:** Document 1 critical process (the one causing the most pain)
**Week 2–3:** Document 2 more processes, one per week
**Month 2:** Aim for 1–2 SOPs per week
**Quarter 1 goal:** 10–15 core processes documented

**Batch recording tip:** Schedule a "Process Documentation Hour" where you interview 2–3 people back-to-back. Record all conversations, then process the transcripts with AI afterward. This is far more efficient than scheduling individual sessions.

### The SOP-from-Screen-Recording Shortcut

For software-based processes, this alternative approach is even faster:

1. Ask the process owner to record their screen while performing the task (using Loom, OBS, or built-in screen recording)
2. Get the video transcribed (Loom does this automatically)
3. Use this specialized prompt:

> **Prompt — SOP from Screen Recording**
>
> Below is a transcript from a screen recording of an employee performing [PROCESS NAME] in [SOFTWARE NAME]. The transcript includes their verbal narration as they click through the process.
>
> Create a detailed SOP that includes:
> - Exact navigation paths (e.g., "Click Settings → Users → Add New")
> - Field names and what to enter in each
> - Screenshots descriptions (describe what the screen should look like at each major step, so we can add screenshots later)
> - Decision points and what determines each path
>
> Format each step as: [Step Number]. [Action] — [Expected Result]
>
> [PASTE TRANSCRIPT]

---

## Common Pitfalls

**❌ Trying to document everything at once.** Start with 1 process. Get the rhythm down. Then scale.

**❌ Making it too detailed.** If a step is truly obvious ("Open your web browser"), skip it. SOPs should respect the reader's intelligence while catching the non-obvious stuff.

**❌ Never updating them.** Set calendar reminders for 6-month reviews. Processes change. SOPs should change with them.

**❌ Skipping the test step.** An SOP that hasn't been tested by someone new is just a rough draft. The 30 minutes you spend testing saves hours of confusion later.

**❌ Making them hard to find.** The best SOP in the world is useless if nobody can find it. Create a simple index document or use a tool like Notion with a searchable database.

---

## Real-World Example

**Process:** Handling a customer refund request

**Recording excerpt (messy, natural speech):**
*"So when someone emails in wanting a refund, first thing I do is check if it's within 30 days, because that's our policy. I go into Stripe, search their email, find the charge. If it's under 30 days I just process it right there. Over 30 days, I have to check with Maria first. Oh, and if it's over €500 I always check with management regardless of the timeframe. Then I send them the confirmation email — there's a template in the shared drive somewhere, I think it's called refund-confirmation or something..."*

**AI output (clean SOP excerpt):**

> **Step 3: Determine Refund Eligibility**
>
> 3.1. Calculate the number of days between the purchase date and today.
>
> 3.2. Apply the following decision rules:
>
> | Condition | Action |
> |---|---|
> | Within 30 days AND under €500 | Proceed to Step 4 (Process Refund) |
> | Within 30 days AND €500 or over | Email management for approval, then proceed to Step 4 |
> | Over 30 days (any amount) | Email Maria (maria@company.com) for approval before proceeding |
>
> ⚠️ **WARNING:** Never process a refund over €500 without written management approval. Save the approval email for records.

See the difference? Same information, but now anyone on the team can handle it correctly.

---

## What Success Looks Like

After implementing this playbook, you should have:

- ✅ A clear, tested SOP for your most critical process
- ✅ A repeatable system for documenting any future process in under an hour
- ✅ Reduced dependency on specific team members
- ✅ Faster onboarding for new hires
- ✅ Fewer "how do I do this?" interruptions

**The real ROI:** Every time a new hire learns a process from your SOP instead of shadowing someone for a day, you've saved two people's time — the new hire's and the trainer's. For a process that takes 2 hours to learn by shadowing, a good SOP pays for itself the first time it's used.
