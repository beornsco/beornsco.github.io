# Chapter 12: Expense Categorization — Automate Your Receipts and Expenses

## What This Playbook Does

Expense management is the tax that every business pays in time. Receipts pile up in wallets, email inboxes, and phone photo libraries. At the end of the month (or worse, at the end of the quarter), someone has to sort through them all, categorize each one, match it to a budget line, and get it into the accounting system.

This playbook shows you how to use AI to automatically categorize expenses from receipts, bank statements, and invoices — reducing a full-day monthly ordeal to 30 minutes of review.

**Time to implement:** 2–3 hours for initial setup, then 30 minutes per month for review.

**Expected time savings:** 4–8 hours per month (depending on volume).

**Tools needed:**
- An AI assistant: ChatGPT (with vision/image capability), Claude, or any LLM
- A spreadsheet: Google Sheets or Excel (free)
- A photo/scanning app: Your phone's camera, Adobe Scan (free), or Genius Scan (free)
- Optional: An OCR tool for batch processing (Google Drive's built-in OCR is free)
- Optional: An accounting tool like QuickBooks, Xero, or Wave (Wave is free)

---

## Why This Is Perfect for AI

Expense categorization has three properties that make it ideal for automation:

1. **It's repetitive.** The same types of expenses recur every month.
2. **It's rule-based.** Most categorization follows simple rules: office supplies go in one bucket, travel in another.
3. **It requires judgment on edge cases.** Is that €45 at a restaurant a "meals & entertainment" expense or a "client meeting" expense? Context matters — and AI can use context.

The human bottleneck isn't the categorization itself — it's the data entry. Pulling information from receipts, typing it into a spreadsheet, and deciding which category fits. AI handles all three.

---

## Step-by-Step Process

### Step 1: Define Your Expense Categories (15 minutes)

Before AI can categorize anything, you need to tell it your categories. If you already have an accounting system, export your chart of accounts. If not, start with this prompt:

> **Prompt — Category Setup**
>
> I run a [TYPE OF BUSINESS] with [NUMBER] employees. Create a practical expense category structure for my business.
>
> Include:
> 1. **Category name** — clear, intuitive label
> 2. **Description** — what belongs in this category
> 3. **Examples** — 3-5 specific examples of expenses in this category
> 4. **Tax relevance** — note if this category has specific tax implications (e.g., deductible, partially deductible, non-deductible) [NOTE: specify your country for tax rules]
>
> Categories should be specific enough to be useful but not so granular that every purchase needs its own category. Aim for 12-20 categories.
>
> My main expense types are:
> [LIST YOUR COMMON EXPENSES — e.g., "office supplies, software subscriptions, client meals, travel, fuel, contractor payments, insurance"]

**Save this as your Category Reference Document.** You'll include it in every categorization prompt.

### Step 2: Set Up Your Receipt Capture System (20 minutes)

The first step to automating categorization is getting receipts into digital format consistently.

**Choose one approach:**

**Option A — Photo to Drive (Simplest):**
1. Create a folder in Google Drive called "Receipts - [Month]"
2. When you get a receipt, photograph it with your phone
3. Upload to the folder (Google Drive app makes this one tap)
4. Google Drive automatically OCRs images, making text searchable

**Option B — Dedicated Scanning App:**
1. Install Adobe Scan or Genius Scan (free)
2. Scan receipts as they come in
3. App auto-crops, enhances, and extracts text
4. Export weekly as PDF or text

**Option C — Email Forwarding:**
1. Create a dedicated email alias: receipts@yourdomain.com
2. Forward digital receipts to this address
3. For physical receipts, photograph and email to the same address
4. Process weekly from this inbox

**The golden rule:** Capture receipts within 24 hours. The longer you wait, the more receipts get lost.

### Step 3: Extract Data from Receipts (Batch Processing)

#### For Individual Receipts (with AI Vision):

If your AI tool supports image input (ChatGPT-4, Claude with vision), you can process receipts directly from photos:

> **Prompt — Single Receipt Extraction**
>
> Extract the following information from this receipt image:
>
> 1. **Vendor/Store name**
> 2. **Date**
> 3. **Total amount** (including currency)
> 4. **Tax amount** (if shown separately)
> 5. **Payment method** (if visible: cash, card ending in XXXX, etc.)
> 6. **Items purchased** (list each line item with amount if legible)
> 7. **Suggested category** based on these categories:
> [PASTE YOUR CATEGORY LIST]
> 8. **Confidence level** for the suggested category (high/medium/low)
> 9. **Notes** — anything unusual or worth flagging
>
> If any field is unreadable, mark it as [UNCLEAR] rather than guessing.
>
> [ATTACH RECEIPT IMAGE]

#### For Batch Processing (Bank Statement Method):

This is more efficient for monthly processing. Export your bank/credit card statement as CSV, then:

> **Prompt — Bank Statement Categorization**
>
> Here is my bank statement for [MONTH]. Categorize each transaction using the following categories:
>
> **Categories:**
> [PASTE YOUR CATEGORY LIST WITH DESCRIPTIONS]
>
> **Rules:**
> - If a vendor appears multiple times, categorize consistently
> - Flag any transaction over €[THRESHOLD] for manual review
> - Flag any transaction that could belong to multiple categories
> - Mark recurring subscriptions as "Subscription" sub-type
> - Ignore transfers between my own accounts
>
> Output as a table with columns:
> Date | Description | Amount | Category | Sub-category | Confidence | Flag
>
> **Bank statement data:**
> [PASTE CSV DATA]

### Step 4: Build Your Vendor-Category Mapping (30 minutes, then maintained automatically)

After processing your first month, AI will have categorized 50-100 transactions. Many of the same vendors will repeat. Create a mapping file:

> **Prompt — Vendor Mapping Generator**
>
> Based on these categorized transactions, create a vendor-to-category mapping table for recurring vendors.
>
> Only include vendors that appear 2+ times or are clearly regular expenses (subscriptions, utilities, etc.).
>
> Format:
> | Vendor Name (as it appears on statements) | Category | Sub-category | Notes |
>
> Also list any vendor name variations that should be treated as the same vendor (e.g., "AMZN*" and "Amazon.com" and "AMAZON MARKETPLACE" → all "Amazon").
>
> Transactions:
> [PASTE ALL CATEGORIZED TRANSACTIONS]

**Save this mapping.** Include it in future categorization prompts so AI automatically uses your established patterns:

> **Prompt Addition — Vendor Mapping (add to any categorization prompt)**
>
> Before categorizing, check this vendor mapping for known vendors. Use the established category. Only categorize manually for new/unknown vendors.
>
> Known vendor mapping:
> [PASTE VENDOR MAPPING TABLE]

### Step 5: Review and Approve (30 minutes per month)

AI categorization is 85-95% accurate for recurring expenses and 70-85% accurate for new vendors. Your job is to review, not redo.

**Review process:**

1. Sort the output by "Confidence" column — review "low" confidence items first
2. Check all "Flagged" items
3. Scan "high confidence" items briefly — are any obviously wrong?
4. Fix any miscategorizations
5. Update your vendor mapping with any new recurring vendors

> **Prompt — Monthly Expense Summary**
>
> Based on these categorized expenses for [MONTH], generate:
>
> 1. **Category summary** — Total spent per category, sorted by amount
> 2. **Month-over-month comparison** — If I provide last month's data, show % change per category
> 3. **Anomalies** — Any categories significantly higher or lower than usual
> 4. **Top 10 vendors** — Biggest spending by vendor
> 5. **Subscription audit** — List all recurring charges identified, with monthly cost
> 6. **Tax-relevant summary** — Group expenses by tax treatment (fully deductible, partially deductible, non-deductible)
>
> This month's data:
> [PASTE CATEGORIZED TRANSACTIONS]
>
> Last month's data (optional):
> [PASTE LAST MONTH'S DATA]

### Step 6: Export to Your Accounting System (15 minutes)

Once reviewed, format the data for your accounting tool:

> **Prompt — Accounting Export Formatter**
>
> Format these categorized expenses for import into [QUICKBOOKS / XERO / WAVE / OTHER].
>
> Required format:
> [PASTE YOUR ACCOUNTING TOOL'S IMPORT FORMAT — usually Date, Description, Amount, Category/Account, Tax Code]
>
> Also generate a simple journal entry summary for this month, grouping by category.
>
> Data:
> [PASTE REVIEWED EXPENSES]

---

## Building the Monthly Routine

Here's what expense management looks like after setup:

**Daily (2 minutes):**
- Photograph any physical receipts → upload to your receipt folder

**Weekly (10 minutes):**
- Forward any digital receipts to your receipts email/folder
- Quick scan: anything unusual this week?

**Monthly (30 minutes):**
1. Export bank/card statement as CSV
2. Run the batch categorization prompt (with vendor mapping)
3. Review flagged and low-confidence items
4. Generate monthly summary
5. Export to accounting system
6. Update vendor mapping if needed

---

## Handling Edge Cases

### Mixed-Purpose Expenses

Some expenses serve multiple purposes (e.g., a laptop used 70% for business, 30% personal):

> **Prompt — Split Expense Handler**
>
> This expense needs to be split across categories:
>
> - Expense: [DESCRIPTION]
> - Total amount: [AMOUNT]
> - Split rationale: [e.g., "70% business use, 30% personal" or "50% marketing, 50% product development"]
>
> Generate the split entries for my expense tracking, including:
> - Separate line items for each portion
> - The business justification for the split
> - Any tax implications of the split in [YOUR COUNTRY]

### Foreign Currency

> **Prompt — Currency Conversion**
>
> These expenses are in foreign currencies. Convert to [YOUR CURRENCY] using the exchange rate from the transaction date.
>
> Expenses:
> [DATE] [AMOUNT] [CURRENCY] — [DESCRIPTION]
>
> For each, provide:
> - Original amount and currency
> - Exchange rate (date-specific)
> - Converted amount in [YOUR CURRENCY]
> - Category assignment

### Receipt OCR Failures

When a receipt is too faded, crumpled, or blurry for AI to read:

1. Try a dedicated OCR app (Adobe Scan has better image enhancement than general AI)
2. If still unreadable, enter manually with this minimum data:
   - Approximate date
   - Vendor (if you remember)
   - Amount (check your bank statement)
   - Category (your best guess)
3. Mark as "Manual entry — receipt quality poor" for audit trail

---

## Common Pitfalls

**❌ Not capturing receipts immediately.** The #1 reason expense tracking fails is lost receipts. Build the habit: receipt → photo → upload. Takes 30 seconds.

**❌ Over-granular categories.** If you have 50 categories, you'll spend more time debating categorization than the system saves. 12-20 categories is the sweet spot.

**❌ Trusting AI blindly on tax-relevant categorization.** AI doesn't know your specific tax situation. Always review the tax-relevant summary with your accountant, especially in the first few months.

**❌ Not maintaining the vendor mapping.** This is your secret weapon for accuracy. Update it monthly and your accuracy rate climbs toward 95%+.

**❌ Procrastinating the monthly review.** The whole point of this system is to make expense management quick and painless. If you let it pile up to quarterly, you've defeated the purpose.

---

## What Success Looks Like

After implementing this playbook, you should have:

- ✅ A consistent receipt capture system (daily habit, takes seconds)
- ✅ Automated categorization that's 85-95% accurate
- ✅ Monthly expense review that takes 30 minutes instead of 4-8 hours
- ✅ Clean data for your accountant (saving them time = saving you money)
- ✅ Monthly spending insights you actually look at

**The real ROI:** Beyond time savings, the biggest value is often what you *discover*. The monthly summary prompt regularly reveals forgotten subscriptions (€15/month you stopped using 6 months ago), spending patterns you didn't notice (eating out costs 3x what you thought), and tax deductions you might have missed. One €50/month subscription you cancel pays for the time investment many times over.
