# Chapter 3: Customer Email Response Automation

## What This Playbook Does

This playbook shows you how to use AI to draft responses to customer emails — cutting the time per email from 3-5 minutes of writing to 30-60 seconds of reviewing and editing.

You'll still send every email yourself (or your team will). AI writes the first draft; humans polish and send. This is Layer 2 automation — AI-assisted with human review.

**Estimated implementation time:** 2-4 hours
**Expected time savings:** 3-5 hours per week (for a team handling 20+ emails/day)
**Difficulty:** Beginner

---

## Tools You'll Need

### Free Options
- **ChatGPT** (free tier) — paste emails in, get draft replies
- **Claude** (free tier at claude.ai) — excellent at matching tone and handling nuance
- **Google Gemini** (free at gemini.google.com) — integrates with Gmail

### Paid Options (for higher volume or integration)
- **ChatGPT Plus** ($20/month) — faster, smarter model, no usage limits during peak times
- **Zendesk AI** (from $55/agent/month) — built-in AI reply suggestions within your helpdesk
- **Freshdesk Freddy AI** (from $29/agent/month) — AI-powered response drafts in your ticketing system
- **Front** (from $19/seat/month) — shared inbox with AI draft features

**Start with the free option.** You can always upgrade later once you see results.

---

## Step-by-Step Setup

### Step 1: Gather Your Reference Material (30 minutes)

Before AI can write replies that sound like your company, it needs context. Collect:

1. **Your 20 most common customer questions** — Ask your team: "What emails do you answer over and over?" Common categories include:
   - Shipping and delivery status
   - Return/refund requests
   - Product questions
   - Pricing inquiries
   - Account/login issues
   - Complaint handling
   - General information requests

2. **5-10 example replies you're happy with** — Actual emails your team has sent that represent how you want to communicate. These teach AI your tone.

3. **Basic company info** — Return policy, shipping times, pricing, business hours, contact details. AI needs facts to give accurate answers.

Save all of this in a single document. This becomes your "company context" that you'll include in your prompts.

### Step 2: Create Your Company Context Block (20 minutes)

Write a block of text that describes how your company communicates. You'll paste this at the top of your AI prompts. Here's a template:

> **Company Context Prompt Template:**
>
> You are a customer service assistant for [Company Name]. We are a [brief description — e.g., "small e-commerce company selling handmade candles"].
>
> Our communication style is: [friendly and warm / professional and concise / casual and approachable — pick one].
>
> Key policies:
> - Returns: [your policy, e.g., "30-day returns, customer pays return shipping"]
> - Shipping: [your info, e.g., "Standard shipping 3-5 business days, express 1-2 days"]
> - Business hours: [your hours, e.g., "Mon-Fri 9-5 CET"]
> - Refunds: [your policy, e.g., "Full refund within 14 days of return receipt"]
>
> Important rules for replies:
> - Always address the customer by name if they provided it
> - Never promise something we can't deliver
> - If you're unsure about something, say "Let me check with our team and get back to you" instead of guessing
> - Keep replies concise — 3-5 sentences for simple questions, more for complex issues
> - Sign off as [name/team name]

### Step 3: Build Your Reply Prompt Template (30 minutes)

This is the prompt you (or your team) will use every time a customer email comes in. Test it a few times and adjust until you like the output.

> **Email Reply Prompt:**
>
> [Paste your Company Context block from Step 2 here]
>
> A customer has sent the following email:
>
> ---
> [Paste the customer's email here]
> ---
>
> Write a reply that:
> 1. Acknowledges their concern or question
> 2. Provides a clear, helpful answer based on our policies
> 3. Offers a next step if applicable
> 4. Maintains our brand tone
>
> Keep the reply concise and professional. Do not include a subject line.

### Step 4: Test with 10 Real Emails (1 hour)

Take 10 recent customer emails and run them through your prompt. For each one:

1. Paste the customer email into ChatGPT or Claude with your prompt
2. Read the AI's draft reply
3. Note what's good and what needs editing
4. Track how long the review/edit takes vs. writing from scratch

**What to look for:**
- Does the tone match your brand?
- Are the facts correct?
- Is the response the right length?
- Does it miss anything the customer asked?

### Step 5: Refine Your Prompt (30 minutes)

Based on your test results, adjust the prompt. Common refinements:

**If replies are too long:**
Add to your prompt: "Keep the reply under 100 words."

**If the tone is too formal:**
Add: "Write in a casual, friendly tone. Use contractions (we're, you'll, etc.)."

**If AI is making up policies:**
Add: "Only reference the policies listed above. If the customer's question isn't covered by these policies, say: 'I'll check with our team on this and get back to you within 24 hours.'"

**If AI misses parts of the customer's email:**
Add: "Before writing the reply, list all questions or concerns the customer raised. Address each one."

### Step 6: Create Category-Specific Prompts (30 minutes)

Once your general prompt works, create specialized prompts for your most common categories. These produce better results than a one-size-fits-all prompt.

> **Refund Request Prompt:**
>
> [Company Context]
>
> A customer is requesting a refund. Their email:
>
> ---
> [Customer email]
> ---
>
> Write a reply that:
> 1. Empathizes with their situation
> 2. Confirms our refund policy (30-day window, original payment method, 5-7 business days processing)
> 3. Asks for their order number if they didn't provide it
> 4. Provides clear next steps
> 5. Reassures them we want to make it right

> **Shipping Status Prompt:**
>
> [Company Context]
>
> A customer is asking about their order/shipping status. Their email:
>
> ---
> [Customer email]
> ---
>
> Write a reply that:
> 1. Thanks them for their order
> 2. Explains our standard shipping timeline (3-5 business days)
> 3. Asks for their order number if they didn't provide it (so we can look up tracking)
> 4. Provides the tracking link format if available: [your tracking URL format]
> 5. Offers to escalate if the order is significantly delayed

> **Complaint Handling Prompt:**
>
> [Company Context]
>
> A customer is unhappy and has written a complaint. Their email:
>
> ---
> [Customer email]
> ---
>
> Write a reply that:
> 1. Leads with a genuine apology — acknowledge what went wrong
> 2. Does NOT make excuses
> 3. Offers a specific resolution (refund, replacement, discount — choose the most appropriate based on the complaint)
> 4. Provides a clear timeline for resolution
> 5. Invites them to reach out if they need anything else
> 6. Tone should be humble and solution-focused

### Step 7: Roll Out to Your Team (30 minutes)

Share the prompts with your team. Here's how to make adoption smooth:

1. **Create a shared document** with all your prompts (Google Doc, Notion page, or even a simple text file)
2. **Demo it live** — show the team how you use it on a real email
3. **Set the expectation:** "AI writes the draft, you own the send button. Always read before sending."
4. **Make it easy** — bookmark ChatGPT/Claude, have the prompts one click away

---

## Example: Before and After

### Customer's Email:
> Hi, I ordered the vanilla candle set last Tuesday and I haven't received any shipping confirmation. Can you tell me what's going on? I need these for a party on Saturday.

### Without AI (Manual — 3-4 minutes to write):
The team member reads, thinks, types, reviews, sends.

### With AI (AI-Assisted — 30-60 seconds to review):

AI draft output:
> Hi [Customer Name],
>
> Thank you for your order! I'm sorry you haven't received a shipping confirmation yet — I understand that's frustrating, especially with your party coming up.
>
> Our standard processing time is 1-2 business days, so your order should have shipped by now. Could you share your order number? I'll look into the status right away and make sure we get it to you as fast as possible.
>
> If it turns out we can't meet your Saturday deadline with standard shipping, I'll explore express options for you.
>
> Thanks for your patience — I'll get back to you quickly!
>
> [Team Name]

The team member reads this, maybe adjusts a line, and sends. Done in under a minute.

---

## Expected Results

| Metric | Before | After |
|--------|--------|-------|
| Time per email | 3-5 minutes | 30-60 seconds |
| Emails handled per hour | 12-20 | 40-60 |
| Time spent on email per day (20 emails) | 60-100 minutes | 10-20 minutes |
| Weekly time savings | — | 3-5+ hours |
| Response quality | Varies by team member | Consistent tone and accuracy |

---

## Common Pitfalls and How to Avoid Them

### Pitfall 1: Sending Without Reading
It will happen. Someone will copy the AI draft, hit send, and not notice the AI hallucinated a policy that doesn't exist. **Prevention:** Make "read before send" a non-negotiable rule. Consider requiring a senior team member to spot-check 10% of AI-drafted replies for the first month.

### Pitfall 2: AI Gets Facts Wrong
AI sometimes invents details — wrong shipping times, non-existent product features. **Prevention:** Your Company Context block should contain all the facts AI needs. If AI still makes things up, add this line to your prompt: "Only include factual claims that are explicitly stated in the company context above."

### Pitfall 3: Over-Relying on One Prompt
Using the same generic prompt for every type of email produces mediocre results. **Prevention:** Build category-specific prompts (Step 6). It takes 30 minutes and dramatically improves output quality.

### Pitfall 4: Team Resistance
"I can write faster than editing an AI draft." Some team members will resist. Usually this changes after they see how much time others save. **Prevention:** Don't mandate it — make it available. The people drowning in email will adopt it immediately. The skeptics will follow.

### Pitfall 5: Not Updating Prompts When Policies Change
If you change your return window from 30 to 14 days but don't update your prompts, AI will give customers wrong information. **Prevention:** Add "Update AI prompts" to your policy change checklist. Assign one person to own the prompt documents.

---

## Scaling Up: From AI-Assisted to Fully Automated

Once you've been running AI-assisted email responses for a month and you're confident in the quality, you might consider moving toward Layer 3:

- **Zendesk AI or Freshdesk Freddy** can auto-suggest replies within your helpdesk — no copy-pasting needed
- **Gmail + Google Gemini** can draft replies right in your inbox
- **For common categories** (shipping status, password reset), you might set up auto-replies that go out without human review — but only for categories where accuracy is consistently 95%+

**Don't rush this.** AI-assisted with human review already saves most of the time. Full automation adds risk for marginal additional savings.

---

## Quick-Start Checklist

- [ ] List your 20 most common customer email types
- [ ] Collect 5-10 example replies that represent your ideal tone
- [ ] Write your Company Context block
- [ ] Build your general reply prompt
- [ ] Test with 10 real emails
- [ ] Refine the prompt based on results
- [ ] Create 3-5 category-specific prompts
- [ ] Share with your team and demo it live
- [ ] Track time savings for the first week
- [ ] Review and update prompts monthly
