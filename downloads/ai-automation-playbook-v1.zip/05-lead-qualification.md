# Chapter 5: Lead Qualification & Scoring

## What This Playbook Does

Every business gets leads — inquiries, form submissions, cold emails, social media messages. The problem isn't getting leads; it's knowing which ones deserve your time right now and which can wait.

Most small businesses treat every lead equally: whoever emailed first gets called first. This means your sales team spends as much time on a "just browsing" inquiry as on a "ready to buy" hot lead.

This playbook shows you how to use AI to score and qualify leads automatically, so your team focuses on the ones most likely to convert. AI reads the lead's information, compares it to your ideal customer profile, and gives you a priority score — all in seconds.

**Estimated implementation time:** 3-5 hours
**Expected time savings:** 3-6 hours per week (less time on bad leads, faster response to good ones)
**Difficulty:** Intermediate

---

## Tools You'll Need

### Free Options
- **ChatGPT or Claude** — for analyzing leads and assigning scores based on your criteria
- **A spreadsheet** (Google Sheets or Excel) — for tracking leads and scores
- **Your existing lead sources** — contact forms, email, social media DMs

### Paid Options (for automation and CRM integration)
- **HubSpot CRM** (free CRM + paid AI features from $20/month) — built-in lead scoring with AI
- **Pipedrive** (from $14/seat/month) — CRM with AI-powered lead scoring
- **Apollo.io** (free tier available) — lead enrichment + scoring
- **Clay** (from $149/month) — AI-powered lead research and enrichment
- **Zapier** ($20/month) — connect your lead sources to AI scoring automatically

**Start free.** Even a manual ChatGPT-based scoring process will save significant time if you're currently scoring leads in your head.

---

## Step-by-Step Setup

### Step 1: Define Your Ideal Customer Profile (30 minutes)

Before AI can score leads, you need to tell it what a good lead looks like. Answer these questions:

**Company characteristics (for B2B):**
- What industry/industries do your best customers come from?
- What company size (employees or revenue) is your sweet spot?
- What geography do you serve?
- Are there any disqualifying factors? (too small, wrong industry, etc.)

**Individual characteristics (for B2B or B2C):**
- What role/title does your buyer typically have?
- What's their typical budget range?
- What pain point drives them to you?

**Behavioral signals:**
- How do good leads typically find you? (referral, search, social media)
- What do they usually say in their first message?
- What actions indicate high intent? (requesting a demo, asking about pricing, mentioning a timeline)

Write this up as your **Ideal Customer Profile (ICP)**. Here's a template:

> **Ideal Customer Profile Template:**
>
> Our best customers are typically:
> - **Industry:** [e.g., professional services, e-commerce, manufacturing]
> - **Company size:** [e.g., 10-100 employees, €500K-€5M revenue]
> - **Location:** [e.g., Benelux region, EU, global]
> - **Decision maker:** [e.g., owner, operations manager, IT director]
> - **Budget:** [e.g., €5K-€50K per project]
> - **Key pain point:** [e.g., spending too much time on manual processes]
>
> High-intent signals:
> - Mentions a specific timeline or deadline
> - Asks about pricing or implementation
> - References a competitor or existing solution they want to replace
> - Was referred by an existing customer
> - Visited our pricing page (if trackable)
>
> Disqualifiers:
> - [e.g., looking for free solutions only]
> - [e.g., outside our service area]
> - [e.g., company too small to afford our minimum engagement]

### Step 2: Create Your Scoring Criteria (30 minutes)

Turn your ICP into a scoring rubric. Each lead will be scored on multiple factors that add up to a total score.

**Suggested scoring model (out of 100 points):**

| Factor | Points | How to Score |
|--------|--------|-------------|
| Industry fit | 0-20 | 20 = perfect fit, 10 = adjacent, 0 = no fit |
| Company size | 0-15 | 15 = sweet spot, 10 = workable, 0 = too small/large |
| Decision-maker level | 0-15 | 15 = owner/C-level, 10 = manager, 5 = individual contributor |
| Budget indicators | 0-15 | 15 = mentions budget in range, 10 = no budget mentioned, 0 = explicitly too low |
| Intent signals | 0-20 | 20 = asks about pricing/timeline, 10 = general inquiry, 0 = vague/cold |
| Source quality | 0-15 | 15 = referral, 10 = organic search, 5 = social media, 0 = unknown |

**Score interpretation:**
- **80-100:** Hot lead — respond within 1 hour
- **60-79:** Warm lead — respond within 24 hours
- **40-59:** Cool lead — add to nurture sequence, respond within 48 hours
- **0-39:** Cold lead — add to mailing list, don't prioritize

Customize these factors for your business. The specific numbers matter less than having a consistent framework.

### Step 3: Build Your Lead Scoring Prompt (30 minutes)

This is the prompt you'll use to score each lead:

> **Lead Scoring Prompt:**
>
> You are a lead qualification assistant for [Company Name]. We are a [brief description].
>
> Our Ideal Customer Profile:
> [Paste your ICP from Step 1]
>
> Scoring criteria (total 100 points):
> - Industry fit (0-20)
> - Company size (0-15)
> - Decision-maker level (0-15)
> - Budget indicators (0-15)
> - Intent signals (0-20)
> - Source quality (0-15)
>
> Score interpretation:
> - 80-100: Hot — respond within 1 hour
> - 60-79: Warm — respond within 24 hours
> - 40-59: Cool — nurture sequence
> - 0-39: Cold — mailing list only
>
> Here is the lead information:
> ---
> [Paste all available lead info: name, company, email, form submission, initial message, source]
> ---
>
> Please provide:
> 1. Score for each criterion with a brief justification
> 2. Total score and category (Hot/Warm/Cool/Cold)
> 3. Key missing information we should try to gather
> 4. Suggested first response approach (what to say, what to ask)
> 5. Any red flags or concerns

### Step 4: Enrich Leads Before Scoring (Optional — 15 minutes setup)

You can improve scoring accuracy by giving AI more context about each lead. Before scoring, do a quick research step:

> **Lead Enrichment Prompt:**
>
> I received a lead from: [Name], [Company], [Email]
>
> Based on their email domain and any available public information, please provide:
> 1. Company description and industry
> 2. Approximate company size (if findable)
> 3. The person's likely role/seniority
> 4. Any recent news about the company
> 5. How this maps to our ideal customer profile: [brief ICP summary]
>
> Note: Only include information you're confident about. If you can't find information, say so rather than guessing.

**Important:** This works best with paid AI tools that have web access (ChatGPT Plus with browsing, or Claude Pro). With free tools, AI will work from the information you provide plus general knowledge about well-known companies.

### Step 5: Process Your First Batch (1-2 hours)

Take your last 20 leads and score them using your prompt. For each lead:

1. Gather all available information (name, company, email, form data, initial message)
2. Optionally run the enrichment prompt
3. Run the scoring prompt
4. Record the score in your spreadsheet

**Spreadsheet columns:**
- Date received
- Name
- Company
- Source
- AI Score (0-100)
- Category (Hot/Warm/Cool/Cold)
- Key notes from AI
- Status (New/Contacted/Meeting/Won/Lost)

### Step 6: Validate Against Reality (30 minutes)

Compare AI scores against what actually happened with those leads:
- Did the "Hot" leads actually convert at a higher rate?
- Were there any "Cold" leads that turned out to be great customers?
- Did the scoring miss any important signals?

Use the results to refine your scoring criteria. This is crucial — your first scoring model won't be perfect, and that's fine. Adjust weights and factors based on real outcomes.

> **Scoring Refinement Prompt:**
>
> I've been using an AI lead scoring system for my business. Here are the results from our last 20 leads:
>
> [Paste a summary: lead, AI score, actual outcome]
>
> Based on these results:
> 1. Which scoring factors seem most predictive of actual conversion?
> 2. Which factors seem least useful?
> 3. Are there patterns in the misscored leads that suggest a new factor we should add?
> 4. Suggest an updated scoring rubric with adjusted weights.

### Step 7: Create a Batch Scoring Workflow (30 minutes)

Once your scoring model is refined, set up a daily or twice-daily routine:

**Daily lead scoring routine (15 minutes):**
1. Open your lead inbox (email, CRM, form submissions)
2. Copy all new lead information
3. Paste into AI with your scoring prompt
4. Record scores in your spreadsheet
5. Hot leads → respond immediately
6. Warm leads → schedule follow-up today
7. Cool leads → add to nurture sequence
8. Cold leads → add to mailing list

**For batch processing multiple leads at once:**

> **Batch Scoring Prompt:**
>
> Score each of the following leads using our criteria. For each lead, provide: Total Score, Category (Hot/Warm/Cool/Cold), Top 2 reasons for the score, and Suggested next action.
>
> [Paste your ICP and scoring criteria]
>
> Lead 1:
> [Info]
>
> Lead 2:
> [Info]
>
> Lead 3:
> [Info]
>
> Format the output as a table for easy scanning.

---

## Example: Before and After

### Before (No Scoring):
Monday morning. 12 new leads from the weekend. Sales rep starts at the top of the inbox and works down. Spends 20 minutes researching and calling a lead that turns out to be a student doing research. Meanwhile, a hot lead from a perfect-fit company waits 3 days for a response and signs with a competitor.

### After (AI-Scored):
Monday morning. 12 new leads scored in 10 minutes. Three are Hot (80+): a referral from an existing customer, a company in the sweet spot asking about pricing, and an ops manager mentioning a Q2 deadline. Sales rep calls those three first. The student inquiry scores 15 and goes to the mailing list automatically. Hot leads get a response within an hour.

---

## Expected Results

| Metric | Before | After |
|--------|--------|-------|
| Time to qualify a lead | 5-15 minutes | 1-2 minutes |
| Response time for hot leads | 1-3 days | Under 2 hours |
| Time spent on unqualified leads per week | 3-5 hours | Under 1 hour |
| Conversion rate (leads → customers) | Baseline | +20-40% improvement |
| Weekly time savings | — | 3-6 hours |

---

## Common Pitfalls and How to Avoid Them

### Pitfall 1: Scoring Based on Gut Instead of Data
AI is only as good as your criteria. If your ICP is based on assumptions rather than actual customer data, your scores will be off. **Prevention:** Look at your last 20 customers. What do they have in common? Build your ICP from reality, not theory.

### Pitfall 2: Treating AI Scores as Gospel
A lead with a score of 35 might still become your biggest customer. Scores are guides, not guarantees. **Prevention:** Always respond to every lead (even cold ones get a polite acknowledgment). Scores determine priority and speed of response, not whether to respond.

### Pitfall 3: Never Updating the Model
Your business evolves. Your ideal customer changes. Your scoring model should too. **Prevention:** Review scores vs. outcomes quarterly. Adjust criteria and weights based on what's actually converting.

### Pitfall 4: Over-Complicating the Score
Some businesses create scoring systems with 20+ factors. This makes the scores harder to understand and harder to act on. **Prevention:** Start with 5-6 factors. Only add more if you find clear signals you're missing.

### Pitfall 5: Scoring Without Acting
Scoring leads is useless if you don't change your behavior based on the scores. **Prevention:** Define clear actions for each category (Hot = call within 1 hour, Warm = email within 24 hours, etc.) and hold your team to them.

---

## Scaling Up: CRM Integration and Automation

Once manual AI scoring is working, consider these upgrades:

- **HubSpot + AI scoring** — automatic lead scoring within your CRM, integrated with your pipeline
- **Zapier workflow** — new form submission → AI scoring via API → score logged in CRM → notification sent to sales rep for hot leads
- **Apollo.io or Clay** — automatic enrichment + scoring on inbound leads

> **Zapier Workflow Example:**
>
> Trigger: New form submission (Typeform, Google Forms, etc.)
> Step 1: Send lead info to ChatGPT API with your scoring prompt
> Step 2: Parse the score from ChatGPT's response
> Step 3: Create/update contact in HubSpot with the score
> Step 4: If score ≥ 80, send Slack notification to sales channel
> Step 5: If score < 40, add to "nurture" email sequence

---

## Quick-Start Checklist

- [ ] Define your Ideal Customer Profile based on actual past customers
- [ ] Create a scoring rubric with 5-6 factors (100-point scale)
- [ ] Build your lead scoring prompt
- [ ] Test with your last 20 leads
- [ ] Compare AI scores with actual outcomes
- [ ] Refine the scoring model based on results
- [ ] Set up a daily scoring routine (15 minutes/day)
- [ ] Define response actions for each score category
- [ ] Train your team on the new prioritization system
- [ ] Review and adjust scores quarterly
