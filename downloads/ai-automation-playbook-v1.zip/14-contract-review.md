# Chapter 14: Contract Review — AI-Assisted Contract Reading for Non-Lawyers

## What This Playbook Does

Contracts are dense. A 6-page vendor agreement, 12-page SaaS terms, or a 3-page NDA can hide critical obligations in passive voice or buried clauses. Lawyers are expensive. Business owners are busy. This playbook shows you a practical, repeatable way to use AI to review contracts quickly, extract the important bits, flag risks, and prepare short, negotiation-ready notes you can share with counsel or use to negotiate directly.

**Time to implement:** 30–90 minutes per contract (depending on complexity).

**Expected time savings:** 1–3 hours per contract versus starting from scratch; more if you use counsel only for high-risk items.

**Tools needed:**
- An AI assistant (ChatGPT, Claude, or other LLM with strong instruction-following)
- A PDF reader or text-extraction tool (Adobe Reader, or OCR for scanned PDFs)
- Optional: Annotations tool (Hypothesis, Kami, or simple PDF comments)
- Optional: Contract lifecycle management (CLM) or a shared drive for storing reviewed contracts

---

## The Contract Review Mindset

Your goal is not to become a lawyer. Your goal is to:

1. Understand obligations, dates, and money flows
2. Identify commercial risks and non-standard terms
3. Produce a short, prioritized negotiation checklist
4. Know which items need legal input and which are business decisions

Contracts naturally contain legalese. You should extract meaning, not rewrite the law. AI helps by translating dense wording into plain language and by applying your business priorities consistently.

---

## Step-by-Step: From Contract to Negotiation Notes

### Step 1: Prepare the Contract Text (5–10 minutes)

If you have a text-based PDF, copy the full text. If the PDF is scanned or an image, run OCR (Adobe, Google Drive, or any OCR tool) and save the extracted text. Save the contract to a central folder: Contracts/Incoming/YYYY-MM.

Why this matters: AI works best with selectable text. Clean input reduces hallucination risk.

### Step 2: High-Level Read & Executive Summary (10 minutes)

Open the contract and skim the structure: headings, term length, payment schedules, termination, IP clauses, warranties, limitations of liability.

Use this prompt to get a quick plain-language summary:

> Prompt — Executive Summary (Quick Read)
>
> You are a business-savvy contract reviewer, not a lawyer. Read the following contract text and provide:
>
> 1. A 5-sentence plain-language executive summary covering: what this contract is, the main deliverables/obligations, who pays whom and when, contract length and renewal terms, and how it ends.
> 2. The five clauses I should read more carefully (list by section heading or by quoting the clause's first line).
> 3. One-sentence assessment of whether this contract is low/medium/high risk for a small business like ours (explain why).
>
> Contract text:
> [PASTE CONTRACT TEXT]

This gives you immediate orientation before deep-diving.

### Step 3: Extract Key Commercial Terms (10 minutes)

Create a consistent summary table for the commercial facts — these are the things business teams actually care about. Use this prompt:

> Prompt — Extract Commercial Terms
>
> Extract the following commercial terms from the contract and output as a table (field: value). If a field is not present or unclear, write [MISSING] or [UNCLEAR].
>
> - Party A (full legal name) — our side
> - Party B (full legal name) — counterparty
> - Effective date
> - Term length & renewal terms (auto-renew? notice required?)
> - Termination rights (for convenience / for cause) and notice periods
> - Payment terms (amounts, schedule, late fees)
> - Minimum commitments / SLAs
> - Deliverables / scope of work
> - Ownership of deliverables / IP assignment or license
> - Confidentiality obligations and duration
> - Data protection / GDPR / security requirements
> - Indemnities (who indemnifies whom and for what)
> - Limitation of liability (caps, exclusions)
> - Insurance requirements
> - Subcontracting / assignment clauses
> - Change control / amendment requirements
> - Governing law and dispute resolution
>
> Contract text:
> [PASTE CONTRACT TEXT]

This outputs a business-ready snapshot you can paste into your CRM or deal file.

### Step 4: Risk & Negotiation Checklist (15–30 minutes)

Now turn the contract into a prioritized, actionable negotiation list. Use this prompt to get an annotated checklist sorted by business impact:

> Prompt — Risk Assessment & Negotiation Priorities
>
> Review the contract and create a prioritized negotiation checklist for our commercial team. For each issue, include:
>
> 1. Short label (e.g., "Auto-renew—short notice")
> 2. Why it matters to the business (one sentence)
> 3. Suggested fallback position we should ask for (exact language where appropriate)
> 4. Severity: High / Medium / Low
> 5. Recommend whether to escalate to legal (Yes/No)
>
> Prioritize the items by severity and business impact. Use the contract text to justify each recommendation.
>
> Contract:
> [PASTE CONTRACT TEXT]

Examples of flags you might get back:
- High: Unlimited liability for all claims — ask to cap at 2x fees or exclude consequential damages
- High: Auto-renew every year with 30-day notice — ask for 60–90-day notice or opt-out clause
- Medium: Vague IP assignment — ask for clarity that pre-existing IP is excluded
- Low: Boilerplate assignment clause — usually acceptable unless you're preparing to sell the business

### Step 5: Redline Suggestions (15–30 minutes)

If you plan to negotiate directly, ask AI to propose specific redline language. Provide both a short ask and a defensive alternative.

> Prompt — Proposed Contract Redlines
>
> For each negotiation item in the checklist, propose:
> - Concise suggested redline (one paragraph of contract text to replace the original clause)
> - A softer alternative phrasing if the counterparty resists
> - A one-sentence rationale we can use in negotiation
>
> Include clause references or the original clause text for context.
>
> Contract text:
> [PASTE CLAUSE OR CONTRACT]

Keep your redlines focused on commercial impact (money, dates, IP, liability, termination). Lawyers can polish the legal finesse later.

### Step 6: Prepare a Negotiation Email / Talking Points (10–20 minutes)

Turn your checklist into a short email or talking points for the negotiation call. Use this prompt:

> Prompt — Negotiation Email Draft
>
> Write a brief, professional negotiation email to the counterparty. Tone: collaborative but firm. Include:
>
> - A one-sentence positive opening: reference the relationship or mutual benefit
> - Bullet list of 3–6 asks (prioritized) with one-line rationale for each
> - A suggested next step (phone call, redline exchange, timeline)
>
> Keep it under 250 words. Use plain language. Sign as [YOUR NAME], [TITLE].
>
> Our negotiation asks:
> [PASTE TOP 3-6 NEGOTIATION ITEMS FROM CHECKLIST]

This email doubles as an audit trail and a clear signal to the other side about what matters to you.

### Step 7: Decide What Needs Legal Review (5–10 minutes)

Not every clause needs a lawyer. The checklist should include a column "Escalate to Legal: Yes/No". High-risk items typically include:
- Unlimited or very large liability exposure
- Complex IP assignments or joint ownership
- Large, long-term financial commitments
- Complex data protection obligations with real-world security requirements
- Unclear or onerous tax/withholding obligations

If you escalate, provide counsel with a short brief: executive summary, commercial terms table, prioritized checklist, and the redlines you suggest. This reduces lawyer time — and your bill.

---

## Special Use Cases & Prompts

### NDAs (Quick review)

NDAs are usually short. Focus on: definition of Confidential Information, exclusions (what's not confidential), duration, return/destroy obligations, and non-solicitation clauses.

> Prompt — NDA Quick Review
>
> Summarize this NDA in 6 bullet points: scope of confidential info, duration, exclusions, permitted disclosures, obligations on return, and remedies. Then flag any unusual or one-sided clauses.
>
> NDA text:
> [PASTE NDA TEXT]

### SaaS Terms & Acceptable Use Policies (AUP)

SaaS terms often contain data and uptime commitments. Focus on data ownership, access to data, backups, uptime SLA credits, liability caps, and export of data upon termination.

> Prompt — SaaS Terms Checklist
>
> Review these SaaS terms and extract the following: data ownership, data portability on termination, SLA and uptime credits, maintenance windows, security certifications, liability cap, and backup frequency. Flag anything that is missing or unusually one-sided.
>
> Terms text:
> [PASTE TEXT]

### Partnership & Revenue Share Agreements

Look at revenue split mechanics, reporting requirements, audit rights, termination triggers, exclusivity, and IP rights. Money and reporting transparency are the critical elements.

> Prompt — Revenue Share Review
>
> Extract: revenue calculation formula, payment timing, reporting frequency, audit rights, clawback provisions, termination impact on revenue sharing, exclusivity, and confidentiality. Flag anything that could create ambiguity in payouts.
>
> Agreement text:
> [PASTE TEXT]

---

## Practical Tips & Best Practices

1. Use consistent naming and storage: Contracts/Incoming, Contracts/Reviewed, Contracts/Executed.
2. Keep a contract register (spreadsheet) with key metadata: counterparty, effective date, renewal date, status, owner, next review.
3. Train your team: make the contract checklist part of the onboarding for sales and procurement.
4. Use version control: when you redline, keep both versions and a short negotiation log.
5. Keep negotiation asks short and commercial — cite business reasons, not legal theory.
6. Track negotiated changes: if you accept a concession, log it in the contract register and alert operations if it affects workflows.

---

## Common Pitfalls

❌ Ignoring the small print: A short clause about "data use" or "subcontractors" can create outsized operational risk.

❌ Treating all contracts the same: A small NDA doesn't need deep review; a 3-year supply contract does.

❌ Starting negotiations with a dense redline: Begin with a few prioritized asks that matter to the business. Large, exhaustive redlines kill momentum.

❌ Not aligning internal stakeholders: If sales negotiates changes, accounting and operations must be aware of any altered payment terms or deliverables.

---

## What Success Looks Like

After implementing this playbook, you should be able to:

- Turn a contract into a clear commercial summary in under 30 minutes
- Produce a prioritized negotiation checklist with suggested redlines
- Know what to escalate to legal and what to handle internally
- Save legal fees by focusing counsel on high-impact items
- Reduce surprises in operations by tracking exceptions and negotiated terms

The practical outcome: faster deals, fewer hidden obligations, and better risk management — without needing a lawyer for every signature.
