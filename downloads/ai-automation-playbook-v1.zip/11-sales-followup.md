# Chapter 11: Sales Follow-Up Sequences — Personalized Outreach on Autopilot

## What This Playbook Does

You had a great meeting. The prospect was interested. You said you'd follow up. And then... life happened. The follow-up email got pushed to tomorrow, then next week, then never. By the time you remember, the prospect has gone cold or signed with a competitor.

This playbook shows you how to build AI-powered sales follow-up sequences that are personalized enough to feel handwritten, consistent enough that no lead ever falls through the cracks, and efficient enough that one person can manage 50+ active prospects without breaking a sweat.

**Time to implement:** 3–4 hours for initial setup, then 15–30 minutes per prospect to personalize.

**Expected time savings:** 5–10 hours per week (for someone managing 20+ active prospects).

**Tools needed:**
- An AI assistant: ChatGPT, Claude, or any capable LLM (free tiers work)
- A CRM or spreadsheet: HubSpot Free, Pipedrive, or Google Sheets
- An email tool: Gmail, Outlook, or any email client
- Optional: An email sequence tool like Mailshake, Lemlist, or HubSpot's free sequences (up to 5 emails per sequence)

---

## Why Generic Follow-Ups Don't Work

Everyone's inbox is full of templates. "Just checking in," "circling back," "wanted to bump this to the top of your inbox" — these phrases trigger an instant delete reflex.

The irony: personalized follow-ups work dramatically better (2-3x higher response rates), but they take dramatically more time. AI closes this gap by generating follow-ups that reference specific details from your conversations, provide genuine value in each touchpoint, and adapt based on the prospect's behavior.

---

## Step-by-Step Process

### Step 1: Map Your Sales Process (20 minutes)

Before building any sequences, you need to know your typical sales journey. Answer these questions:

1. **How do prospects first contact you?** (Inbound form, cold outreach, referral, event)
2. **What happens in the first interaction?** (Discovery call, demo, meeting)
3. **What are the typical decision stages?** (Interest → Evaluation → Negotiation → Decision)
4. **What's the average time from first contact to close?** (1 week? 3 months?)
5. **Who else is involved in the decision?** (Just the prospect? A committee?)
6. **What are the common reasons deals stall?** (Budget, timing, competing priorities)
7. **What are the common objections?** (Price, features, trust, "we're fine as is")

> **Prompt — Sales Process Mapping**
>
> Based on the following information about my sales process, create a visual map showing the stages, typical timelines, and where follow-ups should occur.
>
> Business type: [YOUR BUSINESS TYPE]
> How prospects find us: [CHANNELS]
> Typical sales cycle: [LENGTH]
> Key decision factors: [WHAT MATTERS TO PROSPECTS]
> Common objections: [LIST 3-5]
> Common reasons deals stall: [LIST 3-5]
>
> For each stage, suggest:
> - Number of follow-up touchpoints
> - Spacing between touchpoints
> - Primary goal of each touchpoint
> - Best channel (email, phone, LinkedIn)

### Step 2: Build Your Follow-Up Sequence Templates (60 minutes)

Most B2B sales require 5-8 touchpoints. Here's a proven sequence structure with prompts for each:

---

#### Email 1: Same-Day Recap (Send within 2 hours of meeting)

> **Prompt — Meeting Recap Email**
>
> Write a follow-up email after a sales meeting. Tone: professional, warm, and specific.
>
> Meeting details:
> - Prospect name: [NAME]
> - Company: [COMPANY]
> - Their role: [TITLE]
> - What they need: [THEIR KEY PAIN POINTS/GOALS]
> - What we discussed: [2-3 KEY TOPICS]
> - What I proposed: [SOLUTION OVERVIEW]
> - Next steps we agreed on: [ACTIONS]
> - Personal detail mentioned: [e.g., "They mentioned their team is growing quickly" or "They're launching a new product line in Q2"]
>
> Structure:
> 1. Reference something specific from our conversation (NOT "It was great meeting you")
> 2. Briefly summarize the 2-3 key points and proposed solution
> 3. Restate the agreed next steps with specific dates
> 4. Add one piece of value (relevant article, resource, or insight related to their situation)
> 5. Close warmly
>
> Keep it under 200 words. No attachments — save those for the next email.

---

#### Email 2: Value Drop (Send 2-3 days after Email 1)

> **Prompt — Value-Add Follow-Up**
>
> Write a short follow-up email that provides genuine value without asking for anything.
>
> Context:
> - Prospect name: [NAME]
> - Their industry: [INDUSTRY]
> - Their main challenge: [PAIN POINT]
> - Our previous conversation: [BRIEF SUMMARY]
>
> The email should share one of the following (choose the most relevant):
> - A case study of how we helped a similar company
> - A relevant industry insight or trend
> - A practical tip they can use immediately, regardless of whether they buy from us
> - A resource (article, tool, template) related to their challenge
>
> Tone: helpful, not salesy. This email is about building trust. No pitch, no CTA to buy.
> End with a low-pressure question like "Does this resonate?" or "Have you seen this trend in your business?"
>
> Max 150 words.

---

#### Email 3: Social Proof (Send 5-7 days after Email 1)

> **Prompt — Social Proof Email**
>
> Write a follow-up email that uses social proof relevant to this prospect.
>
> Prospect details:
> - Name: [NAME]
> - Company: [COMPANY]
> - Industry: [INDUSTRY]
> - Company size: [SIZE]
> - Main challenge: [PAIN POINT]
>
> Available social proof (use what's most relevant):
> - Client testimonials: [LIST ANY]
> - Case studies: [BRIEF SUMMARIES]
> - Results/metrics: [SPECIFIC NUMBERS]
> - Industry recognition: [AWARDS, PRESS, etc.]
>
> Structure:
> 1. Brief, natural opener referencing our ongoing conversation
> 2. Transition: "I was thinking about [their specific challenge] and wanted to share..."
> 3. One specific result from a similar client (with numbers if possible)
> 4. Brief quote or result that demonstrates our credibility
> 5. Soft CTA: "Would it help to see the full case study?" or "Want me to connect you with [client name] so you can hear it firsthand?"
>
> Max 175 words. Must feel like genuine sharing, not a pitch.

---

#### Email 4: Objection Preemption (Send 10-12 days after Email 1)

> **Prompt — Objection Handling Email**
>
> Write a follow-up email that proactively addresses the most likely objection for this prospect, without them having raised it.
>
> Prospect details:
> - Name: [NAME]
> - Company: [COMPANY]
> - Stage: They seemed interested but haven't committed
> - Most likely objection: [CHOOSE ONE: price / timing / internal buy-in / existing solution / complexity / trust]
>
> Handle the objection using this framework:
> 1. Acknowledge it's a valid concern (empathy, not defensiveness)
> 2. Reframe it with a different perspective
> 3. Provide proof that addresses it (example, data, guarantee)
> 4. Make it easy to take the next step
>
> Common objection templates:
> - Price: Focus on cost of inaction, ROI, or flexible terms
> - Timing: Acknowledge and offer a smaller starting point
> - Internal buy-in: Offer to present to their team or provide a summary deck
> - Existing solution: Highlight specific gaps without badmouthing competitor
>
> Tone: understanding, confident, not desperate. Max 200 words.

---

#### Email 5: The Breakup Email (Send 20-25 days after Email 1)

> **Prompt — Breakup Email**
>
> Write a final follow-up email in a sequence. This prospect has received 4 previous emails with no response.
>
> Prospect name: [NAME]
> What we discussed: [BRIEF SUMMARY]
>
> Rules:
> - Be direct and honest: acknowledge they may not be interested, and that's okay
> - Give them an easy "out" — don't guilt-trip
> - Leave the door open for future conversations
> - Include a simple 1-click response option (e.g., "Reply with 1 if you want to revisit in 3 months, 2 if the timing is wrong, or 3 if you're all set")
> - Be brief — under 100 words
>
> The goal is to either get a final response or close the loop with dignity.
>
> This email often gets the highest response rate in a sequence because it removes all pressure.

---

### Step 3: Personalize at Scale (15 minutes per prospect)

Here's where the system comes together. For each new prospect, create a "Prospect Brief":

> **Prompt — Prospect Brief Generator**
>
> Based on the following information, create a Prospect Brief I can use to personalize my follow-up sequence.
>
> Information I have:
> - Name: [NAME]
> - Company: [COMPANY]
> - Role: [TITLE]
> - Meeting notes: [PASTE RAW NOTES OR TRANSCRIPT]
> - Their LinkedIn profile summary: [PASTE IF AVAILABLE]
> - Their company's recent news: [PASTE IF AVAILABLE]
>
> Generate:
> 1. **Key pain points** (prioritized)
> 2. **Decision drivers** (what matters most to them)
> 3. **Likely objections** (ranked by probability)
> 4. **Personal connection points** (interests, background, shared connections)
> 5. **Relevant social proof** to use (suggest which of our case studies/results would resonate most)
> 6. **Recommended value-add content** (what article/resource/tip would be most useful to them)
> 7. **Personalization hooks** for each email in the sequence

Then use the Prospect Brief to fill in the variables in each email template. The AI generates the customized version; you review and send.

### Step 4: Set Up Tracking (30 minutes)

You need to know what's working. At minimum, track:

**In your CRM or spreadsheet:**

| Prospect | Email 1 Sent | Opened | Email 2 Sent | Opened | Reply | Stage | Notes |
|----------|-------------|--------|-------------|--------|-------|-------|-------|
| Jane Smith | Mar 1 | ✅ | Mar 4 | ✅ | Mar 5 | Meeting booked | Interested in Q2 |
| Tom Brown | Mar 1 | ✅ | Mar 4 | ❌ | — | Pending | Try phone call |

**Key metrics to watch:**
- **Open rate per email:** If below 30%, your subject lines need work
- **Reply rate per email:** If below 5%, your content needs work
- **Sequence completion rate:** What percentage of prospects make it to Email 5 without responding?
- **Conversion rate:** What percentage of sequenced prospects take the next step?

### Step 5: Iterate Based on Results (Ongoing)

After running the sequence for 20+ prospects, analyze what's working:

> **Prompt — Sequence Performance Analysis**
>
> Here are the results from my sales follow-up sequence over [TIME PERIOD]:
>
> Email 1 (Recap): [OPEN RATE]% open, [REPLY RATE]% reply
> Email 2 (Value): [OPEN RATE]% open, [REPLY RATE]% reply
> Email 3 (Social Proof): [OPEN RATE]% open, [REPLY RATE]% reply
> Email 4 (Objection): [OPEN RATE]% open, [REPLY RATE]% reply
> Email 5 (Breakup): [OPEN RATE]% open, [REPLY RATE]% reply
>
> Overall conversion (prospect → next step): [RATE]%
>
> Here are the subject lines I used:
> [LIST SUBJECT LINES AND THEIR OPEN RATES]
>
> Here are the 3 emails that got the most replies:
> [PASTE EMAILS]
>
> And the 3 that got zero replies:
> [PASTE EMAILS]
>
> Analyze what's working and what's not. Provide specific recommendations for:
> 1. Subject line improvements for low-performing emails
> 2. Content/structure changes for emails with low reply rates
> 3. Timing adjustments (should I space emails differently?)
> 4. Any emails that should be replaced entirely

---

## Advanced Techniques

### Multi-Channel Sequences

Don't limit yourself to email. The most effective follow-up sequences mix channels:

**Day 0:** Email 1 (Recap)
**Day 2:** LinkedIn comment on their recent post
**Day 3:** Email 2 (Value)
**Day 7:** Email 3 (Social Proof)
**Day 8:** LinkedIn message (brief, personal)
**Day 12:** Email 4 (Objection)
**Day 14:** Phone call
**Day 21:** Email 5 (Breakup)

> **Prompt — LinkedIn Touchpoint**
>
> Write a brief LinkedIn message (max 100 words) to send between follow-up emails.
>
> Context:
> - We had a meeting about [TOPIC] on [DATE]
> - I've sent [NUMBER] follow-up emails, [WITH/WITHOUT] response
> - Their recent LinkedIn activity: [PASTE ANY RECENT POSTS OR ARTICLES THEY SHARED]
>
> The message should:
> - Reference their recent LinkedIn activity if possible
> - Be conversational and human
> - NOT pitch or ask for a meeting
> - Create a reason for them to respond naturally
> - Feel like something a real person would send, not a sales automation

### Re-Engagement Sequences

For prospects who went cold months ago:

> **Prompt — Re-Engagement Email**
>
> Write a re-engagement email to a prospect who went cold [TIMEFRAME] ago.
>
> Original context:
> - Name: [NAME]
> - Company: [COMPANY]
> - What we discussed: [SUMMARY]
> - Why they likely went cold: [YOUR GUESS: timing, budget, priorities, etc.]
>
> The email should:
> - Acknowledge the time gap naturally (no guilt, no "sorry to bother you")
> - Offer a legitimate reason for reaching out (new feature, relevant news, industry change, new case study)
> - Respect their intelligence — they know it's a sales email
> - Give them an easy way to re-engage OR a graceful way to opt out
>
> Max 120 words.

---

## Common Pitfalls

**❌ Sending obviously templated emails.** If 10 prospects received identical emails, you're doing it wrong. The Prospect Brief step exists for a reason — use it.

**❌ Following up too aggressively.** 5 emails over 3 weeks is a sequence. 5 emails in 5 days is spam. Space them out.

**❌ Only following up by email.** Email is one channel. A LinkedIn comment + phone call + email combination is 3x more effective than 3 emails.

**❌ Not knowing when to stop.** After the breakup email, stop. If they don't respond to 5 thoughtful touchpoints, they're not interested right now. Add them to a quarterly re-engagement list and move on.

**❌ Forgetting the human element.** AI writes the emails. You build the relationships. The best follow-up in the world won't save a bad product or a bad first meeting. AI amplifies what's already working.

---

## What Success Looks Like

After implementing this playbook, you should have:

- ✅ A 5-email follow-up sequence template customized to your business
- ✅ A system that generates personalized sequences in 15 minutes per prospect
- ✅ No leads falling through the cracks
- ✅ 2-3x higher response rates compared to generic follow-ups
- ✅ Clear data on what messaging works (so you keep getting better)

**The real ROI:** If your average deal is worth €5,000 and better follow-up converts just 2 more deals per quarter, that's €40,000/year in additional revenue from a system that takes 30 minutes per week to maintain. Even for smaller deal sizes, recovering lost leads through consistent follow-up is almost always the highest-ROI activity in a small business.
