# Chapter 9: Content Repurposing Engine — One Piece of Content → 10 Formats

## What This Playbook Does

You wrote a great blog post. Or you gave a talk. Or you recorded a video explaining something you know well. That one piece of content represents hours of thinking, writing, and refining — and most businesses use it exactly once, in exactly one format.

This playbook shows you how to take any single piece of quality content and systematically transform it into 10+ different formats across multiple platforms. One hour of AI-assisted work can generate a week's worth of content across every channel your audience uses.

**Time to implement:** 1–2 hours per content piece (after initial setup of your prompts).

**Expected time savings:** 8–12 hours per content piece (compared to creating each format from scratch).

**Tools needed:**
- An AI assistant: ChatGPT, Claude, or any capable LLM (free tiers work)
- A text editor or Google Doc for your source content
- Canva (free tier) for visual formats
- A scheduling tool: Buffer, Hootsuite, or Later (free tiers available)
- Optional: Descript or CapCut for video/audio editing (free tiers available)

---

## The Content Repurposing Framework

Think of your content as a tree. The **trunk** is your original, long-form piece. The **branches** are medium-form adaptations. The **leaves** are short-form snippets. And the **roots** are the research and data that support everything.

```
                    [Original Content — Blog/Video/Talk]
                           |
          ┌────────────────┼────────────────┐
          |                |                |
     [Medium-form]   [Medium-form]    [Medium-form]
     Newsletter      LinkedIn Article  Podcast Script
          |                |                |
     ┌────┼────┐     ┌────┼────┐     ┌────┼────┐
   [Short] [Short] [Short] [Short] [Short] [Short]
   Tweet   Carousel  Quote   Reel   Thread  Audiogram
```

You're not just copy-pasting — each format is **adapted** for its platform's audience, tone, and constraints.

---

## Step-by-Step Process

### Step 1: Choose Your Source Content (5 minutes)

Your source material should be:
- **Substantial** — at least 800 words or 5 minutes of audio/video
- **Valuable** — teaches something, shares an insight, or solves a problem
- **Evergreen-ish** — still relevant for at least a few months

Good candidates:
- Blog posts or articles you've written
- Talks or presentations you've given
- Podcast episodes or interviews
- Long email responses where you explained something well
- Internal training materials
- Customer case studies

If your source is audio or video, get it transcribed first (see Chapter 8 for transcription options).

### Step 2: Extract the Core Elements (10 minutes)

Before generating any formats, have AI analyze your source content for reusable elements:

> **Prompt — Content Analysis**
>
> Analyze the following content and extract:
>
> 1. **Core thesis** — The single main argument or insight, in one sentence
> 2. **Key points** — 3-5 supporting points or takeaways
> 3. **Quotable lines** — 3-5 sentences that stand alone as powerful statements
> 4. **Data/statistics** — Any numbers, percentages, or concrete results mentioned
> 5. **Stories/examples** — Any anecdotes or case studies included
> 6. **Actionable advice** — Specific steps readers can take
> 7. **Contrarian or surprising elements** — Anything that challenges conventional thinking
> 8. **Target audience** — Who would benefit most from this content
>
> Source content:
> [PASTE YOUR CONTENT]

Save this analysis. It's the foundation for everything that follows.

### Step 3: Generate All 10 Formats

Now the fun part. Work through each format using the prompts below. You can do them in any order, but I've arranged them from highest effort to lowest.

---

#### Format 1: Newsletter Email

Best for: nurturing your email list, driving traffic back to the original

> **Prompt — Newsletter Adaptation**
>
> Transform this content into a newsletter email (400-600 words). The tone should be conversational and personal, as if writing to a friend who's interested in [YOUR INDUSTRY].
>
> Structure:
> - Hook: Open with a question, surprising fact, or brief story (2-3 sentences)
> - Value: Share the key insight and 2-3 most actionable points
> - Story: Include one specific example or case study
> - CTA: End with a single clear call-to-action (read the full article / reply with their experience / try one tip this week)
>
> Do NOT just summarize — rewrite it in a more personal, email-friendly voice. Use "you" frequently. Keep paragraphs to 1-3 sentences.
>
> Source content:
> [PASTE CONTENT]
>
> Brand voice notes: [e.g., "Professional but warm. We use occasional humor. Never corporate-speak."]

---

#### Format 2: LinkedIn Article / Post (Long-form)

Best for: establishing thought leadership, reaching professional audience

> **Prompt — LinkedIn Long-Form Post**
>
> Transform this content into a LinkedIn post (800-1,200 words). LinkedIn's algorithm favors:
> - Strong opening hook (first 2 lines must make people click "see more")
> - Personal perspective and experience
> - Specific, actionable advice
> - Line breaks between short paragraphs (1-2 sentences each)
> - A question at the end to drive comments
>
> Structure:
> - Hook (1-2 lines that create curiosity or state something bold)
> - Personal context (why you care about this topic)
> - Core insight with 3-5 supporting points
> - Specific example or story
> - Actionable takeaway
> - Closing question
>
> Use "I" and "you" language. No bullet-point lists longer than 5 items. Include 3-5 relevant hashtags at the end.
>
> Source content:
> [PASTE CONTENT]

---

#### Format 3: Twitter/X Thread

Best for: viral potential, reaching new audiences, bite-sized education

> **Prompt — Twitter/X Thread**
>
> Transform this content into a Twitter/X thread of 7-12 tweets.
>
> Rules:
> - Tweet 1 (hook): Must be attention-grabbing and self-contained. End with "🧵" or "A thread:"
> - Each tweet: 240 characters max (leave room for engagement). Must make sense on its own AND flow as part of the thread
> - Use concrete numbers and specifics over vague claims
> - Include one tweet that's a counterintuitive or surprising insight
> - Tweet before last: Summarize the key takeaway
> - Final tweet: CTA (follow for more, link to full article, or ask a question)
>
> Format each tweet on its own line, numbered 1/ through N/
>
> Source content:
> [PASTE CONTENT]

---

#### Format 4: Instagram/LinkedIn Carousel

Best for: visual learners, high save/share rates, educational content

> **Prompt — Carousel Script**
>
> Transform this content into a 7-10 slide carousel for Instagram/LinkedIn.
>
> For each slide, provide:
> - **Slide number**
> - **Headline** (5-8 words, large text)
> - **Body text** (15-25 words max — this is overlay text on an image)
> - **Visual suggestion** (what the background or graphic should convey)
>
> Slide structure:
> - Slide 1: Bold hook/title (must stop the scroll)
> - Slides 2-3: The problem or context
> - Slides 4-7: The solution, one point per slide
> - Slide 8-9: Summary or key takeaway
> - Final slide: CTA (save this, follow for more, link in bio)
>
> Keep text minimal — carousels are visual. Each slide should be understandable in 3 seconds.
>
> Source content:
> [PASTE CONTENT]

**Implementation tip:** Take the carousel script into Canva. Use a consistent template. Creating 10 slides takes about 15 minutes once you have the text.

---

#### Format 5: Short-Form Video Script (Reels/TikTok/Shorts)

Best for: reaching younger audiences, algorithm-friendly format, high engagement

> **Prompt — Short Video Script**
>
> Transform this content into a 60-90 second video script for Instagram Reels / TikTok / YouTube Shorts.
>
> Structure:
> - **Hook (0-3 seconds):** Start mid-thought with something surprising. No intros, no "hey guys." Example patterns: "The biggest mistake...", "Nobody tells you that...", "Here's what [result] actually looks like..."
> - **Problem (3-15 seconds):** Briefly state the pain point your audience has
> - **Solution (15-50 seconds):** Share 2-3 specific, actionable tips. Be concrete.
> - **Proof (50-60 seconds):** Quick result, example, or social proof
> - **CTA (60-70 seconds):** "Follow for more" or "Save this for later"
>
> Write it as a spoken script — conversational, short sentences. Include [VISUAL CUE] notes for what to show on screen.
>
> Source content:
> [PASTE CONTENT]

---

#### Format 6: Podcast Talking Points / Solo Episode Script

Best for: audio-first audiences, in-depth discussion, personal connection

> **Prompt — Podcast Episode Outline**
>
> Transform this content into talking points for a 10-15 minute podcast episode (solo format).
>
> Structure:
> - **Cold open** (30 sec): Start with the most interesting point or a provocative question
> - **Intro** (1 min): Set context — why this topic matters right now
> - **Main content** (8-12 min): Walk through the key points conversationally. Include:
>   - Personal anecdotes or client stories
>   - "Here's what most people get wrong" moments
>   - Practical examples
>   - Transitions between sections
> - **Summary** (1 min): Recap the 3 big takeaways
> - **CTA** (30 sec): Ask listeners to do one thing
>
> Write as bullet points with key phrases (not a word-for-word script — it should sound natural when spoken). Include suggested tangents or stories to make it personal.
>
> Source content:
> [PASTE CONTENT]

---

#### Format 7: Quote Graphics (3-5 images)

Best for: high shareability, Instagram stories, Pinterest

> **Prompt — Quotable Excerpts**
>
> From this content, extract or create 5 standalone quotes that work as image overlays. Each quote should:
>
> - Be 10-20 words maximum
> - Make sense without any context
> - Be insightful, surprising, or motivating
> - Work as a square graphic with large text
>
> For each quote, also suggest:
> - A background mood (e.g., "dark and bold", "light and minimal", "nature/calm")
> - A relevant emoji that could accompany it
>
> Source content:
> [PASTE CONTENT]

**Implementation:** Drop these into Canva templates. 2 minutes per graphic.

---

#### Format 8: Email Signature / Forum Response Snippet

Best for: passive distribution, establishing expertise in communities

> **Prompt — Micro-Summary**
>
> Condense this content into a 2-3 sentence summary that could be:
> 1. Used as a response in a relevant online forum or community discussion
> 2. Included as a "latest insight" in an email signature
> 3. Posted as a comment on someone else's related content
>
> Make it valuable on its own — not a teaser. It should demonstrate expertise and naturally make people want to learn more. Include a subtle reference to the full piece without being salesy.
>
> Source content:
> [PASTE CONTENT]

---

#### Format 9: FAQ / Q&A Format

Best for: SEO, voice search optimization, knowledge base content

> **Prompt — FAQ Transformation**
>
> Transform this content into a Q&A / FAQ format with 5-8 questions.
>
> Each question should:
> - Be phrased the way a real person would ask it (natural language)
> - Start with who/what/when/where/why/how
> - Be something someone might actually type into Google
>
> Each answer should:
> - Be 2-4 sentences (concise but complete)
> - Include the key term/phrase from the question in the answer (for SEO)
> - Be factual and directly actionable
>
> Source content:
> [PASTE CONTENT]

---

#### Format 10: Infographic Outline

Best for: Pinterest, blog enhancement, link building, presentations

> **Prompt — Infographic Structure**
>
> Transform this content into an infographic outline with:
>
> 1. **Title** (8 words or fewer, attention-grabbing)
> 2. **Subtitle** (one line explaining what the reader will learn)
> 3. **Sections** (4-6 sections, each with):
>    - Section header (3-5 words)
>    - One key statistic or data point (use a number)
>    - One sentence of explanation
>    - Suggested icon or visual element
> 4. **Footer** — Key takeaway + source/credit
>
> The infographic should tell a story from top to bottom: Problem → Context → Solution → Steps → Result.
>
> Source content:
> [PASTE CONTENT]

**Implementation:** Use Canva's infographic templates or tools like Piktochart (free tier). The AI-generated outline means you're just placing elements, not designing from scratch.

---

### Step 4: Quality Control Each Piece (20–30 minutes)

Don't publish AI output without review. For each format, check:

1. **Accuracy** — Does it faithfully represent the original content?
2. **Platform fit** — Does it follow the conventions of the target platform?
3. **Brand voice** — Does it sound like you/your company?
4. **Value** — Would someone benefit from this even without seeing the original?
5. **CTA alignment** — Does each piece drive toward a business goal?

> **Prompt — Voice Consistency Check**
>
> Compare these two texts. The first is our original content in our brand voice. The second is an adaptation for [PLATFORM].
>
> Identify any places where the adaptation sounds generic, overly formal, or inconsistent with the original voice. Suggest specific rewrites for those sections.
>
> Original: [PASTE EXCERPT FROM SOURCE]
>
> Adaptation: [PASTE THE FORMAT YOU'RE CHECKING]

### Step 5: Schedule and Distribute (15 minutes)

Don't publish everything at once. Spread it out:

**Week 1:**
- Day 1: Publish original long-form content
- Day 2: Send newsletter
- Day 3: Post LinkedIn article
- Day 4: Share Twitter thread
- Day 5: Post first carousel

**Week 2:**
- Day 1-2: Post quote graphics (one per day on Stories)
- Day 3: Share short-form video
- Day 4: Post FAQ version on your website
- Day 5: Share infographic on Pinterest/LinkedIn

This gives you two full weeks of content from one original piece.

---

## The Content Repurposing Workflow (Summary)

| Step | Time | Output |
|------|------|--------|
| Choose source content | 5 min | Selected piece |
| Extract core elements | 10 min | Analysis document |
| Generate 10 formats | 40–60 min | 10 content pieces |
| Quality control | 20–30 min | Polished content |
| Schedule & distribute | 15 min | 2-week content calendar |
| **Total** | **~2 hours** | **10+ pieces of content** |

---

## Building a Repurposing System

### Create Your Prompt Library

After your first round, save all the prompts with your brand voice notes already filled in. Create a document called "Content Repurposing Prompts" with each prompt template ready to go. Next time, you just paste the source content — no prompt engineering needed.

### Batch Processing

The most efficient approach:
1. Write/record 4 pieces of original content per month (1 per week)
2. Block 2 hours every Monday for repurposing the previous week's content
3. Schedule everything for the coming week
4. Result: 40+ pieces of content per month from 4 hours of repurposing work

### Create Templates for Visual Formats

In Canva, create branded templates for:
- Carousel slides (consistent style, colors, fonts)
- Quote graphics (2-3 variations)
- Infographic layout

Once templates exist, going from AI text to finished graphic takes 2-3 minutes per piece.

---

## Common Pitfalls

**❌ Copy-pasting the same text everywhere.** Each platform has different norms. A blog post dumped on LinkedIn performs poorly. The whole point is adaptation, not duplication.

**❌ Not including platform-specific formatting.** LinkedIn loves line breaks. Twitter needs conciseness. Newsletters need a personal touch. If it reads the same on every platform, you're doing it wrong.

**❌ Skipping the quality check.** AI can introduce subtle errors or miss your brand voice. Always review before publishing, especially quotes and statistics.

**❌ Publishing all 10 formats on the same day.** Spread your content out. Each platform's algorithm rewards consistency over bursts.

**❌ Repurposing weak source content.** Garbage in, garbage out. If the original piece isn't valuable, 10 versions of it won't be either. Start with your best content.

---

## What Success Looks Like

After implementing this playbook, you should have:

- ✅ 10+ content pieces from every original piece you create
- ✅ Consistent presence across multiple platforms
- ✅ A repeatable weekly system that takes ~2 hours
- ✅ A growing library of prompt templates customized to your brand
- ✅ More time to create quality original content (because distribution is systematized)

**The real ROI:** If you value your content creation time at €50/hour and each piece of content would normally take 1 hour to create from scratch, repurposing one piece saves you €400–€500 in time. Even if you spend 2 hours on repurposing, you're still saving 8+ hours — a 4x return on your time investment.
