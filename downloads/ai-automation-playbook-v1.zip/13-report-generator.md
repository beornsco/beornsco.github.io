# Chapter 13: Report Generator — Turn Raw Data into Executive Summaries

## What This Playbook Does

Every week, someone in your business exports a spreadsheet, stares at rows of numbers, and tries to figure out what they mean. Then they spend an hour or more turning those numbers into a report that a human can actually understand. Charts get made. Paragraphs get written. The same format gets recreated from scratch every time.

This playbook shows you how to feed raw data — sales figures, website analytics, project updates, financial statements, survey results — into AI and get back polished, insight-driven reports in minutes instead of hours.

**Time to implement:** 1–2 hours for your first report template, then 15–30 minutes per report after that.

**Expected time savings:** 2–5 hours per report (depending on complexity).

**Tools needed:**
- An AI assistant: ChatGPT, Claude, or any capable LLM (free tiers work)
- Your raw data source: spreadsheet, dashboard export, or database report
- A presentation tool (if needed): Google Slides, PowerPoint, or Canva
- Optional: Google Sheets / Excel for chart generation

---

## Why Reports Are Perfect for AI

Traditional report writing has three bottlenecks:

1. **Data interpretation** — What do these numbers actually mean?
2. **Narrative construction** — How do I explain this to someone who hasn't seen the data?
3. **Formatting** — Making it look professional and consistent

AI handles all three. It can identify trends, calculate changes, flag anomalies, and write clear narratives — all from raw numbers. Your job shifts from "creating the report" to "verifying the insights and adding strategic context."

---

## Step-by-Step Process

### Step 1: Define Your Report Template (30 minutes, one-time per report type)

Every recurring report should have a template. This ensures consistency and makes AI output predictable.

> **Prompt — Report Template Builder**
>
> I need to create a recurring [FREQUENCY: weekly/monthly/quarterly] report for [AUDIENCE: my team / the board / clients / investors].
>
> The report covers: [TOPIC — e.g., "sales performance," "marketing metrics," "project status," "financial overview"]
>
> Design a report template with:
>
> 1. **Report title format** — including dynamic elements (date range, period)
> 2. **Executive summary section** — 3-5 sentences that capture the most important takeaways
> 3. **Key metrics dashboard** — The 5-8 most important numbers to highlight, with:
>    - Metric name
>    - Current value
>    - Comparison (vs. last period, vs. target)
>    - Status indicator (↑ ↓ → or 🟢 🟡 🔴)
> 4. **Detailed sections** — What topics to cover in depth (3-5 sections)
> 5. **Insights & recommendations** — What actions should this report suggest?
> 6. **Appendix** — Raw data tables for reference
>
> The audience is [TECHNICAL LEVEL: executive / manager / technical team]. They care most about [WHAT THEY WANT TO KNOW]. Keep the main body under [LENGTH: 1 page / 2 pages / 5 pages].
>
> Also specify what data I need to collect to generate this report.

### Step 2: Prepare Your Data (10 minutes)

AI works best with structured data. Get your numbers into a clean format:

**Option A — Spreadsheet export:**
Export your data as CSV or copy-paste the table. Include headers.

**Option B — Dashboard screenshot:**
If your data lives in a dashboard (Google Analytics, HubSpot, Stripe), export or screenshot it. For AI with vision capability, screenshots work directly. Otherwise, copy key numbers manually.

**Option C — Text summary:**
If data comes from multiple sources, write a quick text summary:
```
Sales this month: €42,500 (target: €50,000)
New customers: 23 (vs 31 last month)
Churn: 4 customers (vs 2 last month)
Top product: Widget Pro (€18,000, 42% of revenue)
Pipeline: €78,000 (12 deals)
```

**Data preparation tips:**
- Always include comparison data (previous period, target, year-ago)
- Include context for unusual numbers (e.g., "Q3 is always slow due to holidays")
- Flag any known data quality issues ("CRM wasn't updated for the first week")

### Step 3: Generate the Report (15 minutes)

Use your template with the current data:

> **Prompt — Report Generator (Master)**
>
> Generate a [FREQUENCY] [REPORT TYPE] report for [DATE RANGE] using the template and data below.
>
> **Report template:**
> [PASTE YOUR TEMPLATE FROM STEP 1]
>
> **Current period data:**
> [PASTE DATA]
>
> **Previous period data (for comparison):**
> [PASTE DATA]
>
> **Targets/goals:**
> [PASTE TARGETS]
>
> **Known context:**
> [ANY CONTEXT — e.g., "We launched a new product mid-month" or "One sales rep was on leave for 2 weeks"]
>
> **Writing guidelines:**
> - Use specific numbers, not vague descriptions ("Revenue grew 12% to €42,500" not "Revenue saw healthy growth")
> - Lead with the most important finding in the executive summary
> - Highlight both wins and concerns — don't sugarcoat
> - Keep recommendations actionable and specific
> - Use [AUDIENCE's] language — [e.g., "no technical jargon" or "assume familiarity with SaaS metrics"]
> - Format with headers, bullet points, and bold key numbers for scanability

### Step 4: Add Visualizations (15 minutes)

AI can describe what charts to create. You then build them in your preferred tool:

> **Prompt — Chart Recommendations**
>
> Based on this report data, recommend 3-5 charts/visualizations that would make the key findings clearer.
>
> For each visualization:
> 1. **Chart type** (bar, line, pie, etc.)
> 2. **What it shows** — the specific insight it communicates
> 3. **Data to include** — exact columns/rows to use
> 4. **Title** — a descriptive title that conveys the insight (not just "Revenue Chart" but "Revenue Trending 12% Below Q4 Target")
> 5. **Placement** — where in the report it should go
>
> Report data:
> [PASTE DATA]

**Quick chart creation:**
- Google Sheets: Paste data → select → Insert → Chart (30 seconds per chart)
- Canva: Use their chart templates with your numbers
- AI tools like ChatGPT with Code Interpreter can generate charts directly from data

### Step 5: Generate the Executive Summary Last (5 minutes)

Even though the executive summary appears first in the report, generate it last — after you've reviewed all sections:

> **Prompt — Executive Summary**
>
> Write a 3-5 sentence executive summary for this report. Rules:
>
> 1. First sentence: The single most important finding (good or bad)
> 2. Second sentence: The key supporting evidence
> 3. Third sentence: The primary risk or opportunity
> 4. Fourth sentence (if needed): Recommended immediate action
>
> The reader should be able to read ONLY this summary and understand the current situation.
>
> Full report:
> [PASTE COMPLETED REPORT]

---

## Report Templates for Common SME Reports

### Weekly Sales Report

> **Prompt — Weekly Sales Report**
>
> Generate a weekly sales report for [DATE RANGE]:
>
> Data:
> [PASTE: deals won, deals lost, pipeline changes, activity metrics]
>
> Include:
> - Revenue vs. target (weekly and MTD)
> - Win/loss analysis (why we won, why we lost)
> - Pipeline health (total value, movement, aging)
> - Rep performance (if applicable)
> - Top 3 deals to watch this week
> - One specific recommendation for next week

### Monthly Financial Summary

> **Prompt — Monthly Financial Summary**
>
> Generate a monthly financial summary for [MONTH]:
>
> Data:
> [PASTE: revenue, expenses by category, cash position, accounts receivable, accounts payable]
>
> Include:
> - P&L summary (revenue, costs, gross margin, net profit)
> - Revenue breakdown by source/product
> - Expense breakdown by category with variance vs. budget
> - Cash flow snapshot (starting balance, in, out, ending balance)
> - Key ratios (gross margin %, burn rate, runway if applicable)
> - 3-month trend for major line items
> - Flags: any category over budget, any receivables overdue

### Monthly Marketing Report

> **Prompt — Monthly Marketing Report**
>
> Generate a monthly marketing performance report for [MONTH]:
>
> Data:
> [PASTE: website traffic, lead sources, conversion rates, email metrics, social media metrics, ad spend and results]
>
> Include:
> - Traffic overview (total, by source, vs. last month)
> - Lead generation (total leads, cost per lead, quality assessment)
> - Channel performance (rank channels by ROI)
> - Content performance (top pages, top posts)
> - Email metrics (list growth, open rates, click rates)
> - Ad performance (spend, clicks, conversions, CPA)
> - Recommendations: what to double down on, what to cut

### Quarterly Business Review

> **Prompt — Quarterly Business Review**
>
> Generate a quarterly business review for [QUARTER]:
>
> Data:
> [PASTE: quarterly financials, key metrics, project status, team updates]
>
> Include:
> - Quarter-over-quarter performance summary
> - Progress against annual goals (% complete, on track / at risk / behind)
> - Key wins this quarter (with specifics)
> - Key challenges and how they were addressed
> - Customer metrics (acquisition, retention, satisfaction)
> - Team/operational updates
> - Strategic priorities for next quarter (max 3-5)
> - Resource needs or budget requests

### Project Status Report

> **Prompt — Project Status Report**
>
> Generate a project status report for [PROJECT NAME]:
>
> Data:
> [PASTE: milestones, tasks completed, tasks pending, timeline, budget spent, issues]
>
> Include:
> - Overall status: 🟢 On Track / 🟡 At Risk / 🔴 Off Track
> - Progress vs. plan (what was supposed to happen vs. what did)
> - Completed this period
> - Planned for next period
> - Blockers and risks (with proposed mitigations)
> - Budget status (spent vs. allocated)
> - Decisions needed from stakeholders
> - Timeline impact (any changes to the completion date?)

---

## Advanced Techniques

### Automated Data Pipeline

For recurring reports, minimize manual data work:

1. **Set up automatic exports:** Most tools (Google Analytics, HubSpot, Stripe, QuickBooks) can email you a CSV report on a schedule
2. **Create a template spreadsheet:** One tab for data paste, one tab for AI-ready output with formulas that calculate period-over-period changes
3. **Use a standardized data format:** Always same column headers, same date format, same currency notation

### Comparative Analysis

> **Prompt — Period Comparison**
>
> Compare these two periods and identify the most significant changes:
>
> Period 1 ([DATE RANGE]): [PASTE DATA]
> Period 2 ([DATE RANGE]): [PASTE DATA]
>
> For each metric:
> - Calculate the absolute and percentage change
> - Rate the significance (major / minor / negligible)
> - Provide a likely explanation for major changes
> - Flag any metrics that changed direction (positive → negative or vice versa)
>
> Rank the findings by business impact, most important first.

### Anomaly Detection

> **Prompt — Anomaly Detection**
>
> Review this data for anomalies — anything that deviates significantly from the pattern.
>
> Historical data (last 6 months):
> [PASTE HISTORICAL DATA]
>
> Current period:
> [PASTE CURRENT DATA]
>
> Identify:
> 1. Any metric more than 20% above or below its 6-month average
> 2. Any sudden trend reversal
> 3. Any metric hitting an all-time high or low
> 4. Any unusual correlations between metrics
>
> For each anomaly, rate:
> - Severity (🔴 high / 🟡 medium / 🟢 low)
> - Likely cause
> - Recommended action

---

## Building a Reporting Rhythm

| Report | Frequency | Time Required | Audience |
|--------|-----------|---------------|----------|
| Sales update | Weekly | 15 min | Sales team + management |
| Financial summary | Monthly | 30 min | Owner + accountant |
| Marketing report | Monthly | 25 min | Marketing + management |
| Project status | Biweekly | 15 min | Project team + stakeholders |
| Business review | Quarterly | 45 min | Leadership + board/investors |

**Total monthly reporting time: ~3 hours** (vs. 15-20 hours doing it manually)

---

## Common Pitfalls

**❌ Presenting AI output without verification.** Always verify the numbers. AI can miscalculate, misinterpret, or hallucinate data points. Spot-check at least 3-4 key numbers against your source data.

**❌ Reports without recommendations.** A report that says "revenue is down 15%" without saying "here's why and here's what to do about it" is only half useful. Always include the "so what?" and "now what?"

**❌ Too many metrics.** Executive reports should highlight 5-8 key metrics. If you're showing 30 numbers, nothing stands out. The detailed data belongs in an appendix.

**❌ Same format for different audiences.** Your board wants strategy and trends. Your team wants tactics and next steps. Use different prompts for different audiences, even from the same data.

**❌ Not building on previous reports.** Reference last month's findings. "Last month we flagged rising customer acquisition costs. This month, they've stabilized at €45/customer after implementing the referral program." This continuity makes reports dramatically more valuable.

---

## What Success Looks Like

After implementing this playbook, you should have:

- ✅ Report templates for your 2-3 most important recurring reports
- ✅ A data preparation workflow that takes minutes, not hours
- ✅ Consistent, professional reports that actually get read
- ✅ Time to focus on strategic interpretation rather than data formatting
- ✅ Historical reports you can compare to track trends over time

**The real ROI:** Reports drive decisions. A clear, insightful monthly report that highlights an underperforming product line or a growing customer segment doesn't just save reporting time — it leads to better business decisions. The difference between good and bad data presentation is often the difference between catching a problem early and discovering it too late.
