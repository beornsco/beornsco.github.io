# Chapter 1: How to Think About Automation

## Stop Thinking "Replace Humans" — Start Thinking "Layers"

Most business owners hear "AI automation" and imagine one of two extremes: either a robot completely running their business, or a fancy chatbot that's more trouble than it's worth. The reality is neither.

The most successful businesses don't automate everything at once. They think in **layers** — gradually moving tasks from fully manual to AI-assisted, and eventually to fully automated. This chapter gives you the mental model to make smart automation decisions instead of expensive mistakes.

---

## The 3-Layer Automation Model

Think of every business task as sitting on one of three levels:

### Layer 1: Manual (Human Does Everything)

This is where most small businesses start — and where many stay longer than they need to. Someone on your team does the task from start to finish using their brain, their time, and their judgment.

**Examples:**
- Reading every customer email and typing a reply from scratch
- Manually entering invoice data into a spreadsheet
- Attending meetings and writing notes by hand afterward
- Reviewing every lead that comes in and deciding who to call

**When this is fine:**
- The task is rare (happens once a month or less)
- It requires deep expertise or nuanced judgment every single time
- The consequences of getting it wrong are severe (legal, financial, reputational)
- You're still figuring out the process itself

**The cost of staying here too long:** Your most expensive resource — human attention — gets burned on repetitive work. A €50,000/year employee spending 5 hours a week on email responses is spending ~€3,000/year on work AI could assist with.

### Layer 2: AI-Assisted (Human + AI Together)

This is the sweet spot for most SMEs right now. AI does the heavy lifting — drafting, sorting, extracting, summarizing — and a human reviews, edits, and approves.

**Examples:**
- AI drafts email responses; a team member reviews and sends
- AI extracts data from invoices; someone verifies the numbers
- AI transcribes meetings and generates action items; the manager checks and assigns
- AI scores leads; a salesperson reviews the top-scored ones

**When this makes sense:**
- The task is repetitive but needs some human judgment
- Getting it 80-90% right automatically is good enough (human catches the rest)
- You want to save time without losing quality
- You're not ready to fully trust AI with the process yet

**Why this layer is powerful:** You get 60-80% of the time savings of full automation with almost none of the risk. The human is still in the loop, catching mistakes and handling edge cases.

### Layer 3: Fully Automated (AI Does Everything)

AI handles the entire task from trigger to completion, with no human involvement. Humans only step in when something breaks or for periodic quality reviews.

**Examples:**
- Chatbot handles common customer questions 24/7, only escalating unusual ones
- Invoices are automatically scanned, categorized, and entered into accounting software
- Meeting recordings are auto-transcribed and action items are posted to your project management tool
- Basic lead scoring happens automatically; only qualified leads reach a human

**When this makes sense:**
- The task is highly repetitive and predictable
- Error tolerance is moderate (small mistakes don't cause major harm)
- You've already tested the AI-assisted version and it works well
- The volume justifies the setup effort

**The trap to avoid:** Jumping straight to full automation without testing AI-assisted first. That's how you end up with an AI chatbot insulting customers or auto-approving fraudulent invoices.

---

## The Golden Rule: Move One Layer at a Time

Here's the single most important principle in this entire playbook:

**Never skip a layer.**

If a task is currently manual, move it to AI-assisted first. Run it that way for 2-4 weeks. Fix the problems. Tune the prompts. Build confidence. *Then* decide if it's worth moving to fully automated.

Companies that try to jump from Layer 1 to Layer 3 almost always:
1. Spend too much money on tools they don't need yet
2. Create automations that produce garbage output
3. Lose trust in AI entirely and go back to manual
4. Waste months instead of saving hours

The incremental approach is faster in the long run because you learn what works before you commit.

---

## Real-World Example: Customer Support Emails

Let's see how this plays out with a real process:

**Layer 1 (Manual):** Sarah reads every email. She types every reply. She handles 30 emails/day, spending about 3 minutes each. That's 1.5 hours of her day, every day.

**Layer 2 (AI-Assisted):** Sarah copies the customer email into ChatGPT with a prompt template. AI drafts a reply in 10 seconds. Sarah reviews it, makes small edits (30 seconds), and sends. Time per email drops from 3 minutes to 1 minute. **She saves 1 hour per day.**

**Layer 3 (Fully Automated):** Common email categories (shipping questions, return requests, password resets) are auto-replied by AI integrated with the helpdesk. Sarah only handles complex or sensitive emails. Her email time drops to 20 minutes/day for the exceptions. **She saves 1 hour 10 minutes per day.**

Notice how Layer 2 alone saved the majority of the time. Layer 3 added more savings, but it also required more setup (integration with helpdesk software, building category rules, testing edge cases). Many businesses would be perfectly happy staying at Layer 2.

---

## The Decision Framework: Should You Automate This?

Before automating any task, ask these five questions:

### 1. How often does this happen?
- Daily or multiple times per day → Strong candidate
- Weekly → Good candidate
- Monthly or less → Probably not worth automating yet

### 2. How repetitive is it?
- Same basic process every time → Strong candidate
- Similar but with frequent variations → AI-assisted is good; full automation is risky
- Completely different every time → Keep it manual

### 3. What happens if AI gets it wrong?
- Minor inconvenience (can be easily corrected) → Safe to automate
- Moderate impact (annoyed customer, wrong data) → Use AI-assisted with human review
- Severe consequences (legal issues, lost money, damaged reputation) → Keep heavy human oversight

### 4. How much time does it consume?
- 5+ hours per week → High-priority automation target
- 1-5 hours per week → Worth automating if it's straightforward
- Less than 1 hour per week → Probably not worth the setup effort

### 5. Do you understand the process well?
- Yes, it's well-documented and predictable → Ready to automate
- Sort of, but there are lots of judgment calls → AI-assisted only
- No, it's in someone's head → Document it first, automate later

**Quick decision:** If a task scores "strong candidate" on at least 3 out of 5 questions, it's worth trying AI-assisted automation. Start there.

---

## What NOT to Automate (Yet)

Some things aren't ready for automation, no matter how much time they take:

- **Relationship-building conversations** — AI can draft follow-ups, but genuine connection needs a human
- **Strategic decisions** — AI can provide analysis, but choosing your company's direction is yours
- **Creative work that defines your brand** — AI can help, but your unique voice comes from you
- **Processes you don't understand yet** — Automating chaos just creates faster chaos
- **One-time or rare tasks** — The setup time won't pay off

---

## Your Starting Mindset

Going into the rest of this playbook, keep these principles in mind:

1. **Start with AI-assisted, not full automation.** Every playbook in this book will show you the assisted version first.
2. **Think in hours saved, not perfection achieved.** Saving 5 hours a week with 90% accuracy beats spending months chasing 100%.
3. **One process at a time.** Pick the highest-impact task, automate it, stabilize it, then move to the next.
4. **Your team's trust matters.** If your employees fear AI will replace them, they'll sabotage it. Position AI as their assistant, not their replacement.
5. **Budget is not the bottleneck.** Most of the playbooks in this book can be started with free tools. Time and attention are the real costs.

---

## What's Next

In Chapter 2, you'll learn a simple scoring system to decide which tasks to automate first — so you get the biggest wins fastest. Then from Chapter 3 onward, we'll dive into specific playbooks you can implement this week.

Let's figure out your priorities.
