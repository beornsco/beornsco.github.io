# Chapter 6: Meeting Notes & Action Items

## What This Playbook Does

You finish a meeting. Everyone agrees on next steps. Then… nothing happens. Three days later, someone asks "Wait, who was supposed to do that?" Sound familiar?

This playbook shows you how to use AI to automatically transcribe meetings, generate clear summaries, and extract specific action items with owners and deadlines. Instead of someone furiously taking notes (and missing half the conversation), AI handles the documentation so your team can focus on the actual discussion.

**Estimated implementation time:** 2-3 hours
**Expected time savings:** 2-4 hours per week (plus fewer dropped action items)
**Difficulty:** Beginner

---

## Tools You'll Need

### Free Options
- **Otter.ai** (free tier — 300 minutes/month) — records and transcribes meetings, works with Zoom/Teams/Meet
- **Google Docs voice typing** — basic transcription for in-person meetings
- **ChatGPT or Claude** — for summarizing transcripts and extracting action items
- **Phone voice recorder** — as a backup for in-person meetings

### Paid Options (for better accuracy and integration)
- **Otter.ai Pro** ($17/month) — more minutes, better accuracy, auto-join virtual meetings
- **Fireflies.ai** (from $18/month) — transcription + AI summary + CRM integration
- **Granola** (free tier available) — AI meeting notepad, works alongside your meeting app
- **Read.ai** (from $20/month) — transcription, summaries, meeting analytics
- **Microsoft Copilot** (included in Microsoft 365 Copilot, $30/user/month) — transcription and notes built into Teams
- **tl;dv** (free tier available) — records Google Meet/Zoom calls, AI summaries

**Recommendation:** Start with Otter.ai free tier or tl;dv. Both auto-join virtual meetings and provide transcripts you can then process with ChatGPT/Claude.

---

## Step-by-Step Setup

### Step 1: Choose Your Recording Method (15 minutes)

**For virtual meetings (Zoom, Teams, Google Meet):**
- Sign up for Otter.ai, Fireflies.ai, or tl;dv
- Connect it to your calendar
- The tool will auto-join meetings as a "participant" and record/transcribe
- Make sure to inform attendees about the recording (legal requirement in most places)

**For in-person meetings:**
- Use your phone's voice recorder app
- Place the phone in the center of the table
- After the meeting, upload the audio file to Otter.ai for transcription or use the manual transcript method below

**For hybrid meetings:**
- Use the virtual meeting tool's built-in recording plus Otter.ai/Fireflies for transcription

### Step 2: Create Your Meeting Summary Prompt (20 minutes)

After getting a transcript (either from your transcription tool or by hand), use this prompt to generate a structured summary:

> **Meeting Summary Prompt:**
>
> Below is a transcript from a meeting. Please create a structured meeting summary with these sections:
>
> **1. Meeting Overview**
> - Date: [date]
> - Attendees: [list everyone who spoke]
> - Duration: approximately [X] minutes
> - Purpose: [one-sentence summary of why the meeting happened]
>
> **2. Key Discussion Points**
> - Summarize each major topic discussed in 2-3 sentences
> - Note any decisions that were made
> - Note any disagreements or open questions
>
> **3. Action Items**
> For each action item, provide:
> - [ ] **Task:** [specific task description]
> - **Owner:** [person responsible]
> - **Deadline:** [date or timeframe mentioned — if none mentioned, write "TBD"]
> - **Context:** [one sentence on why this matters]
>
> **4. Decisions Made**
> - List each decision clearly, including who made it
>
> **5. Open Questions / Parking Lot**
> - List any unresolved topics that need follow-up
>
> **6. Next Meeting**
> - Date/time if scheduled, or note "to be scheduled"
> - Agenda items for next meeting if mentioned
>
> Transcript:
> ---
> [Paste the transcript here]
> ---

### Step 3: Handle Meetings Without a Transcript (Alternative)

If you can't record a meeting (sensitive topic, client preference, or technical issues), you can still use AI with manual notes:

> **Notes-to-Summary Prompt:**
>
> I just attended a meeting and took rough notes. Please organize these into a structured meeting summary with clear action items.
>
> Meeting context: [What was the meeting about? Who attended?]
>
> My rough notes:
> ---
> [Paste your shorthand notes here — bullet points, fragments, whatever you jotted down]
> ---
>
> Please:
> 1. Create a clean summary organized by topic
> 2. Extract all action items with owners (based on the names mentioned)
> 3. List any decisions that were made
> 4. Identify anything that seems unresolved
> 5. Fill in any obvious gaps if the notes are incomplete (mark these as "[inferred]")

### Step 4: Set Up Your Distribution Workflow (30 minutes)

A meeting summary is only useful if people see it. Set up a consistent process:

**Option A — Email (simplest):**
After each meeting, email the summary to all attendees within 1 hour.

**Option B — Shared workspace:**
Post summaries to a dedicated Notion page, Google Drive folder, or Slack channel.

**Option C — Project management integration:**
Copy action items directly into your project management tool (Asana, Trello, Monday.com, etc.) as tasks assigned to the right people.

> **Action Items Extraction Prompt (for project management tools):**
>
> From this meeting summary, extract just the action items in this format:
>
> Task: [specific task]
> Assignee: [person]
> Due: [date or "TBD"]
> Priority: [High/Medium/Low based on the discussion context]
>
> [Paste the meeting summary]

### Step 5: Test with Three Real Meetings (1-2 hours total)

Run the system for your next three meetings:

1. Record/transcribe the meeting
2. Run the transcript through your summary prompt
3. Review the AI summary for accuracy
4. Send to attendees and ask: "Does this capture everything? Any corrections?"
5. Note what AI got right, what it missed, and what it got wrong

**Common feedback to expect:**
- "It missed the discussion about X" → the transcript might have been unclear; refine prompts
- "The action item should be assigned to Y, not Z" → AI sometimes mixes up who volunteered for what
- "The tone is too formal" → add "Write in a casual, direct tone" to your prompt
- "The summary is too long" → add "Keep each section concise. Total summary should be under 500 words."

### Step 6: Refine Based on Feedback (20 minutes)

Common refinements:

**If summaries are too long:**
> Add: "Keep the summary concise. Key discussion points should be 1-2 sentences each. Total summary should fit on one page."

**If action items are vague:**
> Add: "Each action item must be specific enough that the owner knows exactly what to do without re-reading the transcript. Bad: 'Follow up on proposal.' Good: 'Send revised pricing proposal to ABC Corp including the 15% volume discount discussed.'"

**If AI misattributes actions:**
> Add: "When extracting action items, only assign ownership when someone explicitly volunteered or was asked to do it. If ownership is unclear, mark the owner as 'TBD — needs clarification.'"

**If decisions aren't captured well:**
> Add: "For each decision, include: what was decided, who made the call, and the reasoning if it was discussed."

### Step 7: Build the Habit (Ongoing)

The hardest part isn't the technology — it's making it a consistent practice. Here's how:

1. **Make recording automatic** — set Otter.ai/Fireflies to auto-join all calendar events
2. **Assign the "note sender" role** — one person per meeting runs the transcript through AI and sends the summary
3. **Set a time rule** — summaries must be sent within 2 hours of meeting end
4. **Start meetings with a reminder** — "This meeting will be recorded and AI-summarized. Action items will be sent to everyone afterward."
5. **End meetings with a check** — "Let's quickly confirm: who's doing what by when?" This gives AI cleaner data to work with.

---

## Example: Before and After

### Before (Manual Notes):
45-minute team meeting. Project manager tries to take notes while participating. Misses a key discussion while writing. After the meeting, spends 20 minutes cleaning up notes. Emails them the next day (because they ran out of time). Two of four action items are vague. By the following week, one item was forgotten entirely.

### After (AI-Assisted):
Same 45-minute meeting. Otter.ai records and transcribes automatically. Project manager fully participates in the discussion. After the meeting, they paste the transcript into Claude (2 minutes). Review the AI summary (3 minutes). Send to all attendees with action items clearly listed (1 minute). Total post-meeting time: 6 minutes instead of 20+. All four action items are specific with owners and deadlines.

---

## Expected Results

| Metric | Before | After |
|--------|--------|-------|
| Time spent on meeting notes | 15-30 min per meeting | 5-8 min per meeting |
| Time until notes are distributed | Same day to next day | Within 1-2 hours |
| Action items captured | 60-70% (human note-taker misses some) | 90-95% (transcript captures everything) |
| Action items completed on time | ~50% | ~80% (clear owners and deadlines help) |
| Weekly time savings (5 meetings/week) | — | 2-4 hours |

---

## Common Pitfalls and How to Avoid Them

### Pitfall 1: Forgetting to Inform Attendees About Recording
Recording without consent can be illegal and will definitely damage trust. **Prevention:** Always announce at the start: "This meeting is being recorded for note-taking purposes." Add it to your meeting invite template.

### Pitfall 2: Transcription Errors Causing Wrong Action Items
Transcription tools sometimes mishear words, especially names, technical terms, or accented speech. **Prevention:** Always review the AI summary before distributing. Correct any misheard names or terms.

### Pitfall 3: Death by Documentation
Not every meeting needs full documentation. A casual 5-minute check-in doesn't need a structured summary. **Prevention:** Only apply the full process to substantive meetings (30+ minutes, multiple participants, decisions being made).

### Pitfall 4: Action Items Without Follow-Up
Extracting action items is step one. Following up on them is where the real value is. **Prevention:** Start your next meeting by reviewing last meeting's action items. Or set up a weekly action item review.

### Pitfall 5: Sensitive Meeting Content in AI Tools
If you're discussing confidential information (HR issues, legal matters, financials), think twice before sending the transcript to a cloud AI tool. **Prevention:** For sensitive meetings, use the manual notes approach (Step 3) and only share non-sensitive details with AI.

---

## Advanced: Recurring Meeting Templates

For meetings that happen weekly with a similar structure, create a specialized prompt:

> **Weekly Team Meeting Summary Prompt:**
>
> This is our weekly team meeting (held every [day]). Please summarize using our standard format:
>
> **Status Updates:** What did each person report on?
> **Blockers:** What obstacles were raised?
> **Decisions:** What was decided?
> **Action Items:** Who committed to what, by when?
> **Metrics Mentioned:** Any numbers or KPIs discussed?
> **Kudos:** Any wins or recognition mentioned?
>
> Transcript:
> [Paste here]

---

## Quick-Start Checklist

- [ ] Sign up for a transcription tool (Otter.ai, tl;dv, or Fireflies.ai)
- [ ] Connect to your calendar for auto-join
- [ ] Create your meeting summary prompt
- [ ] Inform your team about the new recording + summary process
- [ ] Test with your next 3 meetings
- [ ] Gather feedback from attendees
- [ ] Refine the prompt based on feedback
- [ ] Set up your distribution workflow (email, Slack, Notion, etc.)
- [ ] Create the "action item review" habit in your next meetings
- [ ] Track time savings and action item completion rates
