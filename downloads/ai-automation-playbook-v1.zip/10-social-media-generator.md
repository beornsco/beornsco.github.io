# Chapter 10: Social Media Post Generator — Brand-Consistent Posts at Scale

## What This Playbook Does

Social media is a volume game. You need to show up consistently — 3-5 times per week minimum — and every post needs to sound like *you*, not like a robot. Most small businesses either post sporadically (when they remember) or burn out trying to keep up.

This playbook gives you a system for generating weeks of brand-consistent social media content in a single sitting using AI. You'll create a brand voice guide, build a post generation system, and develop a workflow that produces 20+ posts per month in under 3 hours of total work.

**Time to implement:** 2–3 hours for initial setup (brand voice + templates), then 1–2 hours per month for ongoing content generation.

**Expected time savings:** 8–15 hours per month (compared to writing each post individually).

**Tools needed:**
- An AI assistant: ChatGPT, Claude, or any capable LLM (free tiers work)
- A spreadsheet: Google Sheets or Excel (free)
- A scheduling tool: Buffer, Hootsuite, or Later (free tiers support 3 channels)
- Canva (free tier) for any visual posts
- Optional: A social media analytics tool for measuring performance

---

## Why AI-Generated Social Media Usually Fails

Before we build the system, let's address the elephant in the room: most AI-generated social media content is obvious and bad. It's generic. It uses phrases no human would say. It includes too many emojis. It sounds like every other AI-generated post on the internet.

The fix isn't better prompts — it's **better input**. AI needs three things to generate good social content:

1. **Your actual voice** — not a description of your voice, but examples of it
2. **Your specific expertise** — not generic industry advice, but your unique perspective
3. **Platform-specific constraints** — each platform has unwritten rules

This playbook gives AI all three.

---

## Step-by-Step Process

### Step 1: Build Your Brand Voice Document (45 minutes, one-time setup)

This is the most important step. It's a one-time investment that makes everything after it dramatically better.

**Gather 10-15 examples of your best writing:**
- Past social media posts that performed well
- Email responses you're proud of
- Blog posts or articles
- Slack/Teams messages that captured your voice
- Customer testimonials (to understand how others perceive you)

Paste them all into one document, then use this prompt:

> **Prompt — Brand Voice Analysis**
>
> Analyze these writing samples from [YOUR NAME/COMPANY]. All are written by the same person/brand. Extract a detailed brand voice profile:
>
> 1. **Tone** — Overall feeling (e.g., authoritative but approachable). Describe on 3-4 spectrums:
>    - Formal ←→ Casual
>    - Serious ←→ Playful
>    - Technical ←→ Simple
>    - Reserved ←→ Bold
>
> 2. **Vocabulary patterns** — Words and phrases that appear frequently. Industry-specific terms used. Any words that are deliberately avoided.
>
> 3. **Sentence structure** — Average length. Do they use fragments? Questions? Lists?
>
> 4. **Personality markers** — Humor style (if any). How they show expertise. How they connect with readers. Any recurring themes or values.
>
> 5. **What they NEVER do** — Based on these samples, what communication patterns are absent? (e.g., never uses corporate jargon, never uses exclamation marks, never self-promotes directly)
>
> 6. **Example phrases** — Generate 10 phrases that sound like this person/brand based on the patterns you've identified.
>
> Writing samples:
> [PASTE ALL SAMPLES]

**Save the output as your Brand Voice Document.** You'll reference it in every social media prompt going forward.

### Step 2: Define Your Content Pillars (15 minutes)

Content pillars are the 4-6 topics you consistently post about. Having defined pillars prevents the "what should I post about?" paralysis.

> **Prompt — Content Pillar Development**
>
> I run a [TYPE OF BUSINESS] that helps [TARGET AUDIENCE] with [CORE SERVICE/PRODUCT].
>
> Our key differentiators are:
> - [DIFFERENTIATOR 1]
> - [DIFFERENTIATOR 2]
> - [DIFFERENTIATOR 3]
>
> Suggest 5 content pillars for our social media presence. Each pillar should:
> - Relate to our expertise and audience interests
> - Be broad enough to generate 20+ unique posts
> - Include a mix of educational, entertaining, and promotional angles
>
> For each pillar, provide:
> - Pillar name (2-3 words)
> - Description (1 sentence)
> - 5 example post topics

**Example output:**
1. **Behind the Scenes** — How we actually work, real examples and processes
2. **Industry Myths** — Calling out bad advice and misconceptions
3. **Quick Tips** — One actionable tip per post
4. **Client Wins** — Results and success stories (anonymized if needed)
5. **Opinion / Hot Take** — Our honest perspective on industry trends

### Step 3: Create Your Post Generation Prompt (20 minutes)

This is the master prompt you'll use every month. It combines your brand voice, content pillars, and platform-specific rules:

> **Prompt — Weekly Post Batch Generator**
>
> You are the social media manager for [COMPANY NAME]. Your job is to write social media posts that sound authentically like the brand — not like AI.
>
> **Brand Voice:**
> [PASTE YOUR BRAND VOICE DOCUMENT FROM STEP 1]
>
> **Content Pillars:**
> [PASTE YOUR PILLARS FROM STEP 2]
>
> **Platform: [CHOOSE ONE — LinkedIn / Instagram / Twitter/X / Facebook]**
>
> **Platform-specific rules:**
> - [See platform guidelines below]
>
> Generate [NUMBER] posts for the next [TIME PERIOD]. For each post, include:
>
> 1. **Pillar** — Which content pillar it falls under
> 2. **Post text** — The full post, ready to copy and paste
> 3. **Visual suggestion** — What image/graphic to pair with it (if applicable)
> 4. **Best posting time** — Suggested day and time
> 5. **Engagement hook** — How the post encourages interaction (question, poll, CTA)
>
> Mix up the pillars — don't cluster them. Vary post length and format. At least 20% should be short (under 50 words).
>
> Important: Write like a real person. No post should start with a generic hook like "In today's fast-paced world..." or "Have you ever wondered...". Start mid-thought, with a bold claim, or with a specific detail.

#### Platform-Specific Rules to Include:

**For LinkedIn:**
```
- Max 3,000 characters, but sweet spot is 800-1,500
- First 2 lines must hook (everything after is behind "see more")
- Use line breaks between short paragraphs
- End with a question to drive comments
- 3-5 hashtags at the end
- No emojis in the first line
- Personal stories outperform generic advice
```

**For Instagram (captions):**
```
- Max 2,200 characters, but sweet spot is 150-300 for feed posts
- Front-load the value (first line is all most people read)
- Use line breaks for readability
- 20-30 hashtags in first comment (not in caption)
- Include a clear CTA: save, share, comment, or link in bio
- Pair every post with a visual description
```

**For Twitter/X:**
```
- Max 280 characters per tweet
- No hashtags in the tweet body (use 1-2 only if essential)
- Thread format for longer content (mark with 🧵)
- Bold, opinionated takes perform best
- Quote-tweet worthy content: stats, hot takes, frameworks
- Use "ratio-bait" occasionally (controversial but defensible opinions)
```

**For Facebook:**
```
- Sweet spot: 80-200 characters for highest engagement
- Questions and polls drive comments
- Link posts get suppressed — put links in comments
- Native content outperforms shared links
- Community-focused language works best
```

### Step 4: Generate a Month's Worth of Content (30 minutes)

Run the master prompt for each platform you use. If you post on 2 platforms, 5 times per week each, that's 40 posts per month.

**Efficiency tip:** Generate for your primary platform first, then use this adaptation prompt for secondary platforms:

> **Prompt — Platform Adaptation**
>
> Here are [NUMBER] posts written for [ORIGINAL PLATFORM]. Adapt each one for [TARGET PLATFORM], following these rules:
>
> [PASTE PLATFORM-SPECIFIC RULES]
>
> Keep the core message and brand voice identical, but adjust:
> - Length and format for the new platform
> - Tone (LinkedIn is more professional, Twitter is more punchy, etc.)
> - CTAs appropriate to the platform
> - Any platform-specific conventions
>
> Original posts:
> [PASTE POSTS]

### Step 5: Create a Content Calendar (15 minutes)

Organize your posts in a spreadsheet with these columns:

| Date | Platform | Pillar | Post Text | Visual | Status |
|------|----------|--------|-----------|--------|--------|
| Mon 3/24 | LinkedIn | Quick Tip | [post text] | Graphic: stat overlay | Scheduled |
| Tue 3/25 | Instagram | Behind the Scenes | [post text] | Photo: workspace | Draft |

> **Prompt — Content Calendar Optimizer**
>
> Here are my [NUMBER] posts for [MONTH]. Arrange them into an optimal posting schedule considering:
>
> - Don't post the same content pillar two days in a row
> - Alternate between long and short posts
> - Put highest-value content on Tuesday-Thursday (highest engagement days for most B2B)
> - Promotional posts should be no more than 20% of total
> - Space out similar topics by at least 3-4 days
>
> Output as a table with: Date | Day | Platform | Pillar | Post Title/First Line
>
> Posts:
> [PASTE ALL POSTS WITH PILLAR LABELS]

### Step 6: Review, Edit, and Add Personality (30 minutes)

This is the step that separates good from great. Go through every post and:

1. **Read it out loud.** If it sounds weird when spoken, rewrite it. Real social media posts sound natural.

2. **Add specificity.** Replace any generic statements with specific examples from your business. "We helped a client improve their process" → "We helped a bakery in Cork cut their order processing time from 2 hours to 15 minutes."

3. **Check for AI-isms.** Remove:
   - "In today's [adjective] world..."
   - "Here's the thing..."
   - "Let me tell you..."
   - Excessive emojis
   - Lists of exactly 5 items (AI loves lists of 5)
   - The word "landscape"
   - "Game-changer" / "revolutionary"

4. **Add your unique perspective.** For opinion-based posts, make sure it actually reflects YOUR opinion, not a generic middle-ground take.

> **Prompt — AI-ism Checker**
>
> Review these social media posts and flag any that contain:
> - Phrases that are obviously AI-generated (generic hooks, corporate language, clichés)
> - Information that's too vague to be valuable
> - Tone inconsistencies with this brand voice: [PASTE BRIEF VOICE DESCRIPTION]
> - Any post that you wouldn't stop scrolling for
>
> For each flagged post, suggest a specific rewrite that sounds more human and authentic.
>
> Posts:
> [PASTE ALL POSTS]

### Step 7: Schedule and Post (15 minutes)

Load everything into your scheduling tool. Most free-tier schedulers let you upload a CSV or copy-paste individual posts.

Set aside 10 minutes per day for **engagement** — responding to comments, liking relevant posts, and sharing others' content. AI generates the content; you provide the human connection.

---

## Maintaining Brand Consistency Over Time

### Monthly Voice Calibration

Every month, review your top-performing posts and update your brand voice document:

> **Prompt — Voice Calibration**
>
> Here are my 5 best-performing social media posts from last month (based on engagement):
>
> [PASTE TOP 5 POSTS]
>
> And here are the 3 worst-performing:
>
> [PASTE BOTTOM 3 POSTS]
>
> Analyze what makes the top performers work and why the bottom ones fell flat. Update this brand voice profile with any new patterns:
>
> [PASTE CURRENT BRAND VOICE DOCUMENT]

### Trending Topic Integration

When something relevant happens in your industry:

> **Prompt — Reactive Post Generator**
>
> [INDUSTRY EVENT/NEWS] just happened. Generate 3 social media posts reacting to this from our brand's perspective.
>
> Our relevant expertise/angle: [YOUR UNIQUE TAKE]
>
> Brand voice: [PASTE VOICE DOCUMENT]
>
> Platform: [PLATFORM]
>
> These should be posted within 24 hours, so prioritize timeliness and a clear point of view. Don't just report the news — add value through our expertise.

---

## Common Pitfalls

**❌ Using the same prompt without your brand voice document.** This is the #1 reason AI social content sounds generic. Always include your voice document.

**❌ Never posting anything spontaneous.** Your scheduled content should be the backbone, not the entirety. Leave room for real-time posts about what's actually happening in your business.

**❌ Ignoring analytics.** Check what performs. Double down on what works. Retire content pillars that consistently underperform.

**❌ Generating the same types of posts.** Mix formats: short text, long-form, questions, polls, stories, tips, opinions, behind-the-scenes.

**❌ Automating engagement.** Schedule the posts; do the engagement yourself. People can tell when comments are automated, and it damages trust.

---

## The Complete Monthly Workflow

| Task | Time | Frequency |
|------|------|-----------|
| Update brand voice document | 15 min | Monthly |
| Generate month's posts (all platforms) | 45 min | Monthly |
| Review and edit posts | 30 min | Monthly |
| Create/select visuals | 30 min | Monthly |
| Schedule posts | 15 min | Monthly |
| Daily engagement (comments, replies) | 10 min | Daily |
| **Total monthly setup** | **~2.5 hours** | |
| **Total including daily engagement** | **~6 hours/month** | |

Compare that to the 15-20 hours most businesses spend on social media content creation each month.

---

## What Success Looks Like

After implementing this playbook, you should have:

- ✅ A documented brand voice that ensures consistency
- ✅ 20+ posts per month per platform, scheduled in advance
- ✅ A repeatable monthly system that takes under 3 hours
- ✅ Increasing engagement as you refine what works
- ✅ More time for actual engagement and relationship building

**The real ROI:** Consistency is what wins on social media. Posting 4x per week, every week, for 6 months will outperform sporadic bursts of daily posting every time. This system makes consistency achievable for a team of one.
