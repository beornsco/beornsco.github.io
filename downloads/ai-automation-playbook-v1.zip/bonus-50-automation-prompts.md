# 50 Ready-to-Use AI Automation Prompts for SMEs

> Copy-paste these prompts directly into ChatGPT, Claude, or your AI tool of choice.
> Replace everything in [BRACKETS] with your specific details.

---

## 1. Customer Email Responses (Prompts 1–5)

### Prompt 1 — Standard Customer Reply
```
You are a customer service agent for [COMPANY NAME], a [INDUSTRY] business.
A customer emailed about [ISSUE/TOPIC]. Draft a professional, friendly reply that:
- Acknowledges their concern
- Provides a clear resolution or next step
- Keeps the tone [WARM/FORMAL/CASUAL]
- Is under 150 words

Customer email:
[PASTE CUSTOMER EMAIL HERE]
```
**Best for:** Everyday customer inquiries where you need a quick, polished reply.

### Prompt 2 — Complaint De-escalation
```
A customer is upset about [SPECIFIC COMPLAINT] with our [PRODUCT/SERVICE].
They've been a customer for [DURATION]. Write a de-escalation email that:
- Validates their frustration without admitting fault
- Offers [SPECIFIC REMEDY: refund/discount/replacement/escalation]
- Includes a concrete timeline for resolution
- Ends with a retention-focused closing

Their message:
[PASTE COMPLAINT HERE]
```
**Best for:** Angry customers where you need to save the relationship.

### Prompt 3 — Order Status Update
```
Write a [SHIPPING DELAY/BACKORDER/PROCESSING] notification email for [COMPANY NAME].
Order details: [ORDER NUMBER], [PRODUCT], originally expected [DATE].
New expected date: [NEW DATE]. Reason: [BRIEF REASON].
Tone: [APOLOGETIC/MATTER-OF-FACT]. Include a [DISCOUNT CODE/GOODWILL GESTURE] if appropriate.
```
**Best for:** Proactive communication about order issues before customers complain.

### Prompt 4 — Batch Email Classifier
```
I'm going to paste [NUMBER] customer emails. For each one, provide:
1. Priority: Urgent / Normal / Low
2. Category: [BILLING/TECHNICAL/SHIPPING/GENERAL/COMPLAINT]
3. Suggested response summary (1–2 sentences)
4. Estimated response time needed

Emails:
[PASTE EMAILS SEPARATED BY "---"]
```
**Best for:** Morning email triage — sorting a full inbox in minutes instead of hours.

### Prompt 5 — Multilingual Customer Reply
```
Translate and adapt this customer service reply for a [LANGUAGE]-speaking customer.
Don't just translate — adapt the tone for [CULTURE/REGION] business norms.
Keep it professional but culturally appropriate.

Original English reply:
[PASTE YOUR ENGLISH REPLY]

Customer's original message (in [LANGUAGE]):
[PASTE THEIR MESSAGE]
```
**Best for:** SMEs with international customers who can't afford multilingual staff.

---

## 2. FAQ & Knowledge Base (Prompts 6–9)

### Prompt 6 — FAQ Generator from Support History
```
Based on these [NUMBER] recent customer support conversations, identify the top 10 most common questions and write clear, concise FAQ answers for each.

Format each as:
**Q:** [Question as a customer would ask it]
**A:** [Answer in 2–3 sentences, plain language]

Support conversations:
[PASTE CONVERSATIONS OR SUMMARIES]
```
**Best for:** Building your first FAQ page from real customer data.

### Prompt 7 — Knowledge Base Article
```
Write a knowledge base article for [TOPIC] aimed at [AUDIENCE: customers/employees/partners].
Product/Service: [NAME AND BRIEF DESCRIPTION]
Include:
- Clear title and summary
- Step-by-step instructions (if applicable)
- Common pitfalls or mistakes
- Related articles to suggest: [LIST TOPICS]
Reading level: [BASIC/INTERMEDIATE/TECHNICAL]
```
**Best for:** Creating self-service docs that actually reduce support tickets.

### Prompt 8 — FAQ Refresh & Gap Analysis
```
Here's our current FAQ page. Review it and:
1. Flag any answers that sound outdated or vague
2. Suggest 5 questions we're probably missing based on [INDUSTRY] norms
3. Rewrite any weak answers to be clearer
4. Add "Related:" links between connected questions

Current FAQ:
[PASTE FAQ CONTENT]

Our products/services: [BRIEF DESCRIPTION]
```
**Best for:** Quarterly FAQ audits to keep self-service content fresh.

### Prompt 9 — Internal Wiki Entry
```
Write an internal knowledge base entry for our team about [PROCESS/TOOL/POLICY].
Context: We're a [SIZE] team in [INDUSTRY].
Include:
- When to use this process
- Step-by-step walkthrough
- Who to contact if something goes wrong: [NAME/ROLE]
- Last updated: [DATE]
Keep it scannable — bullet points over paragraphs.
```
**Best for:** Documenting tribal knowledge so it doesn't live in one person's head.

---

## 3. Lead Qualification (Prompts 10–13)

### Prompt 10 — Lead Scoring from Form Submissions
```
Score these leads from 1–10 based on our ideal customer profile:
- Industry: [TARGET INDUSTRIES]
- Company size: [EMPLOYEE RANGE]
- Budget range: [BUDGET]
- Decision timeline: [TIMEFRAME]
- Pain points we solve: [LIST]

For each lead, provide: Score, Reasoning (1 line), Recommended next action.

Lead submissions:
[PASTE FORM DATA]
```
**Best for:** Prioritizing inbound leads when you can't follow up with everyone.

### Prompt 11 — Discovery Call Prep
```
I have a sales call with [CONTACT NAME], [TITLE] at [COMPANY NAME].
They're in [INDUSTRY], roughly [SIZE] employees, found us via [SOURCE].
They mentioned interest in [PRODUCT/SERVICE].

Prepare:
1. 5 discovery questions tailored to their likely pain points
2. 3 potential objections and rebuttals
3. Relevant case study angles from [OUR INDUSTRY/SIMILAR CLIENTS]
4. Suggested next steps to propose
```
**Best for:** Walking into sales calls prepared instead of winging it.

### Prompt 12 — Cold Outreach Personalization
```
Write a personalized cold email to [CONTACT NAME], [TITLE] at [COMPANY].
Research context: [PASTE LINKEDIN SUMMARY OR COMPANY INFO].
Our offer: [PRODUCT/SERVICE AND KEY BENEFIT].
Hook angle: [RECENT NEWS/PAIN POINT/INDUSTRY TREND].
Keep it under 100 words. No generic "I hope this finds you well."
CTA: [BOOK A CALL/REPLY/WATCH DEMO]
```
**Best for:** Personalizing outreach at scale without sounding like a template.

### Prompt 13 — Lead Nurture Sequence
```
Create a 5-email nurture sequence for leads who [DOWNLOADED RESOURCE/ATTENDED WEBINAR/SIGNED UP FOR TRIAL].
Our product: [NAME AND VALUE PROP].
Target persona: [ROLE, INDUSTRY, PAIN POINTS].
Sequence timing: [DAYS BETWEEN EMAILS].
Each email should be under 150 words with one clear CTA.
Tone: [HELPFUL/AUTHORITATIVE/CASUAL].
```
**Best for:** Automating follow-up so warm leads don't go cold.

---

## 4. Meeting Notes & Action Items (Prompts 14–18)

### Prompt 14 — Meeting Summary & Action Items
```
Summarize this meeting transcript into:
1. **Key Decisions** (bullet points)
2. **Action Items** (who, what, deadline)
3. **Open Questions** (unresolved issues)
4. **Next Meeting** (suggested agenda items)

Meeting context: [TEAM/CLIENT/PROJECT NAME], [DATE]
Attendees: [NAMES AND ROLES]

Transcript:
[PASTE TRANSCRIPT OR NOTES]
```
**Best for:** Turning rambling hour-long meetings into actionable 1-pagers.

### Prompt 15 — Client Meeting Follow-Up Email
```
Based on this meeting summary, draft a follow-up email to [CLIENT NAME].
Tone: [PROFESSIONAL/FRIENDLY/FORMAL]
Include:
- Thank them for their time
- Recap the key points discussed
- List agreed-upon next steps with owners
- Propose next meeting date: [DATE/TIME OPTIONS]
- Attach reference to [DOCUMENT/PROPOSAL] if mentioned

Meeting notes:
[PASTE NOTES]
```
**Best for:** Sending follow-ups within 30 minutes of a call instead of 3 days.

### Prompt 16 — Weekly Team Standup Summary
```
Compile these individual standup updates into a team summary.
Highlight:
- Blockers that need immediate attention
- Cross-team dependencies
- Items at risk of missing deadlines
- Wins worth celebrating

Format as a Slack/Teams-ready message under 300 words.

Individual updates:
[PASTE UPDATES FROM TEAM MEMBERS]
```
**Best for:** Managers who need a digest instead of reading every standup update.

### Prompt 17 — Board/Investor Meeting Prep
```
Prepare a structured agenda and talking points for our [BOARD/INVESTOR/ADVISORY] meeting.
Company: [NAME], Stage: [SEED/SERIES A/GROWTH/SME]
Key metrics this period: [REVENUE, GROWTH, CHURN, etc.]
Challenges to address: [LIST]
Asks/decisions needed: [LIST]
Time allocated: [DURATION]
```
**Best for:** Making sure important meetings are focused and productive.

### Prompt 18 — Meeting Transcript Cleanup
```
Clean up this rough meeting transcript. Fix grammar, remove filler words (um, uh, like, you know), identify speakers where possible, and format it as a readable document with timestamps every [5/10/15] minutes.

Don't change the meaning — just make it professional and scannable.

Raw transcript:
[PASTE RAW TRANSCRIPT]
```
**Best for:** Making AI-generated transcripts from Otter.ai or Fireflies actually readable.

---

## 5. Document Processing (Prompts 19–22)

### Prompt 19 — Invoice Data Extraction
```
Extract the following fields from this invoice:
- Vendor name
- Invoice number
- Date
- Due date
- Line items (description, quantity, unit price, total)
- Subtotal, tax, total
- Payment terms
- Bank/payment details

Output as a structured table. Flag anything that looks unusual or missing.

Invoice text:
[PASTE INVOICE TEXT OR OCR OUTPUT]
```
**Best for:** Processing vendor invoices without manual data entry.

### Prompt 20 — Document Comparison
```
Compare these two versions of [DOCUMENT TYPE: contract/proposal/policy].
Highlight:
1. Added sections or clauses
2. Removed content
3. Changed wording (show old → new)
4. Potential impact of each change

Version 1:
[PASTE VERSION 1]

Version 2:
[PASTE VERSION 2]
```
**Best for:** Reviewing contract redlines or policy updates quickly.

### Prompt 21 — Resume/CV Screening
```
Screen these [NUMBER] resumes against this job description.
For each candidate, rate fit (1–10) and provide:
- Key strengths for this role
- Potential concerns
- Interview question suggestions
- Recommendation: Advance / Maybe / Pass

Job description:
[PASTE JD]

Resumes:
[PASTE RESUMES SEPARATED BY "---"]
```
**Best for:** First-pass screening when you're drowning in applications.

### Prompt 22 — Form/Survey Response Analysis
```
Analyze these [NUMBER] survey/form responses and provide:
1. Key themes and patterns (with frequency)
2. Sentiment breakdown (positive/neutral/negative)
3. Notable outlier responses
4. Top 3 actionable insights
5. Suggested follow-up actions

Survey topic: [TOPIC]
Responses:
[PASTE RESPONSES]
```
**Best for:** Making sense of customer feedback or employee surveys without a data analyst.

---

## 6. SOP Generator (Prompts 23–27)

### Prompt 23 — SOP from Scratch
```
Create a Standard Operating Procedure for: [PROCESS NAME]
Department: [DEPARTMENT]
Performed by: [ROLE]
Frequency: [DAILY/WEEKLY/AS NEEDED]

Include:
1. Purpose and scope
2. Prerequisites/tools needed
3. Step-by-step instructions (numbered)
4. Decision points (if X, then Y)
5. Quality checks
6. Troubleshooting common issues
7. Version and last-updated date

Context about the process:
[DESCRIBE THE PROCESS IN YOUR OWN WORDS]
```
**Best for:** Turning "the way we've always done it" into a documented, trainable process.

### Prompt 24 — SOP from Video/Walkthrough Notes
```
I recorded myself doing [TASK] and here are my rough notes/transcript.
Turn this into a clean, professional SOP that a new hire could follow independently.
Add any safety warnings or common mistakes you can infer.
Include screenshots placeholders where a visual would help: [SCREENSHOT: description].

My notes:
[PASTE ROUGH NOTES OR TRANSCRIPT]
```
**Best for:** Converting screen recordings or walkthroughs into written procedures.

### Prompt 25 — Employee Onboarding Checklist
```
Create a [DURATION]-day onboarding checklist for a new [ROLE] at [COMPANY NAME].
Team: [TEAM/DEPARTMENT]
Tools they'll use: [LIST OF TOOLS]
Key people to meet: [NAMES AND ROLES]
Include:
- Day-by-day breakdown
- Setup tasks (accounts, equipment)
- Training milestones
- First deliverable expectations
- 30/60/90 day goals
```
**Best for:** Consistent onboarding that doesn't depend on who's training the new hire.

### Prompt 26 — Process Optimization Review
```
Here's our current SOP for [PROCESS]. Review it and suggest:
1. Steps that could be automated (and with what tool)
2. Redundant or unnecessary steps
3. Missing steps or quality checks
4. Time estimates per step
5. Risk points where errors are most likely

Current SOP:
[PASTE SOP]

Tools available to us: [LIST YOUR CURRENT TOOLS]
```
**Best for:** Finding automation opportunities in existing processes.

### Prompt 27 — Emergency/Incident Response Procedure
```
Create an incident response procedure for: [SCENARIO: data breach/server outage/customer data loss/workplace injury].
Company: [NAME], Size: [EMPLOYEES], Industry: [INDUSTRY].
Include:
- Immediate actions (first 15 minutes)
- Escalation matrix (who to call and when)
- Communication templates (internal + external)
- Documentation requirements
- Post-incident review process
```
**Best for:** Being prepared for crises before they happen — not writing the playbook during one.

---

## 7. Content Repurposing (Prompts 28–31)

### Prompt 28 — Blog Post to Multi-Format
```
Repurpose this blog post into:
1. LinkedIn post (under 1300 characters, hook + insight + CTA)
2. Twitter/X thread (5–7 tweets, each standalone)
3. Email newsletter blurb (3 paragraphs, casual tone)
4. Instagram caption (with emoji, hashtag suggestions)
5. Short-form video script (60 seconds, conversational)

Blog post:
[PASTE BLOG POST]
```
**Best for:** Getting 5x the mileage from every piece of content you create.

### Prompt 29 — Podcast/Video to Blog Article
```
Turn this [PODCAST/VIDEO] transcript into a [WORD COUNT]-word blog article.
- Add a compelling headline and meta description
- Structure with H2/H3 headings
- Include key quotes from the conversation
- Add an introduction and conclusion not in the original
- SEO target keyword: [KEYWORD]
- Remove filler and keep only valuable insights

Transcript:
[PASTE TRANSCRIPT]
```
**Best for:** Turning long-form audio/video into searchable, shareable written content.

### Prompt 30 — Case Study from Raw Notes
```
Write a customer case study based on these notes.
Client: [COMPANY/NAME] (get permission before publishing)
Industry: [INDUSTRY]
Challenge: [WHAT THEY STRUGGLED WITH]
Solution: [WHAT WE DID]
Results: [METRICS/OUTCOMES]

Format: Problem → Solution → Results → Quote → CTA
Length: [500–800 WORDS]
Include a suggested pull quote and headline.
```
**Best for:** Turning happy customer stories into sales tools.

### Prompt 31 — Presentation to Document
```
Convert this slide deck content into a [FORMAT: whitepaper/blog post/executive summary/handbook].
Add transitions, context, and detail that slides skip.
Maintain the original structure unless a better flow is obvious.

Slide content:
[PASTE SLIDE TEXT, SLIDE BY SLIDE]

Audience: [WHO WILL READ THIS]
Purpose: [WHY WE'RE CONVERTING IT]
```
**Best for:** When someone asks "can you send me that presentation as a document?"

---

## 8. Social Media (Prompts 32–36)

### Prompt 32 — Weekly Social Media Calendar
```
Create a 5-day social media content calendar for [COMPANY NAME].
Platforms: [LINKEDIN/TWITTER/INSTAGRAM/FACEBOOK]
Industry: [INDUSTRY]
Brand voice: [PROFESSIONAL/PLAYFUL/AUTHORITATIVE/FRIENDLY]
This week's themes: [LIST 2–3 THEMES OR TOPICS]
Include: Post text, suggested image/graphic description, best posting time, hashtags.
Mix content types: [EDUCATIONAL/BEHIND-THE-SCENES/PROMOTIONAL/ENGAGEMENT]
```
**Best for:** Planning a week's content in 10 minutes instead of scrambling daily.

### Prompt 33 — LinkedIn Thought Leadership Post
```
Write a LinkedIn post about [TOPIC] from the perspective of [YOUR ROLE] in [INDUSTRY].
Style: [STORYTELLING/DATA-DRIVEN/CONTRARIAN/LESSONS-LEARNED]
Include:
- A hook that stops the scroll (first line is everything)
- Personal insight or experience angle
- Actionable takeaway for the reader
- CTA: [COMMENT/SHARE/LINK]
Length: [SHORT (~500 chars) / MEDIUM (~1000 chars) / LONG (~1300 chars)]
```
**Best for:** Building personal brand on LinkedIn without staring at a blank screen.

### Prompt 34 — Social Media Reply/Engagement
```
Draft replies to these [NUMBER] social media comments/mentions.
Brand voice: [DESCRIPTION]
Rules:
- Never be defensive
- Add value in every reply
- Use humor when appropriate
- Escalate negative comments: flag but don't engage publicly
- Keep replies under [WORD LIMIT] words

Comments:
[PASTE COMMENTS]
```
**Best for:** Maintaining engagement without spending all day on social media.

### Prompt 35 — Hashtag & Trend Research
```
For [INDUSTRY/NICHE] on [PLATFORM], suggest:
1. 10 evergreen hashtags we should always use
2. 5 trending/timely hashtags for [THIS WEEK/MONTH]
3. 3 branded hashtag ideas for [COMPANY NAME]
4. Hashtag groupings for different content types:
   - Educational posts
   - Promotional posts
   - Community/engagement posts
```
**Best for:** Optimizing discoverability without hashtag guesswork.

### Prompt 36 — Social Proof / Testimonial Posts
```
Turn these raw customer testimonials into polished social media posts.
For each, create versions for: [LINKEDIN / INSTAGRAM / TWITTER].
Add context, emoji where appropriate, and a CTA.
Keep the customer's authentic voice — don't over-polish.

Raw testimonials:
[PASTE TESTIMONIALS]

Customer names/handles (if permitted): [LIST]
```
**Best for:** Showcasing happy customers in a way that drives engagement.

---

## 9. Sales Follow-Up (Prompts 37–40)

### Prompt 37 — Post-Demo Follow-Up
```
Write a follow-up email after a product demo with [CONTACT NAME] at [COMPANY].
Demo covered: [FEATURES/TOPICS SHOWN]
They were most interested in: [SPECIFIC INTEREST]
Their main concern was: [OBJECTION/HESITATION]
Next step to propose: [TRIAL/PROPOSAL/SECOND MEETING]
Urgency factor: [NONE/QUARTER-END/COMPETITOR EVALUATION/BUDGET DEADLINE]
```
**Best for:** Striking while the iron is hot after a demo.

### Prompt 38 — Proposal Follow-Up Sequence
```
Create a 4-email follow-up sequence for a proposal sent to [COMPANY] on [DATE].
Deal size: [AMOUNT]. Decision maker: [NAME, ROLE].
Proposal was for: [PRODUCT/SERVICE SUMMARY].

Email 1 (Day 2): Check-in, answer questions
Email 2 (Day 5): Add value, share relevant [CASE STUDY/ARTICLE]
Email 3 (Day 10): Create gentle urgency
Email 4 (Day 15): Break-up email (last attempt)

Each email under 100 words. Never sound desperate.
```
**Best for:** Systematic follow-up that doesn't feel pushy.

### Prompt 39 — Win-Back Email
```
Write a re-engagement email to [CONTACT/COMPANY] who:
- Was a customer from [DATE] to [DATE]
- Left because of [REASON IF KNOWN]
- We've since [IMPROVEMENT/NEW FEATURE/PRICE CHANGE]

Tone: [HUMBLE/CONFIDENT/CASUAL]
Offer: [DISCOUNT/FREE TRIAL/CONSULTATION]
Make it feel personal, not automated.
```
**Best for:** Recovering churned customers who might give you a second chance.

### Prompt 40 — Referral Request
```
Write a referral request email to [CUSTOMER NAME], a happy customer for [DURATION].
They recently [POSITIVE INTERACTION: left a review/renewed/expanded].
We're looking for referrals in [TARGET INDUSTRY/ROLE/COMPANY SIZE].
Incentive: [DISCOUNT/GIFT/CREDIT/NONE — just asking].
Keep it genuine and short. Max 100 words.
```
**Best for:** Systematically asking for referrals when the timing is right.

---

## 10. Expense Categorization (Prompts 41–43)

### Prompt 41 — Bulk Expense Categorization
```
Categorize these expenses using these categories: [LIST YOUR CHART OF ACCOUNTS OR CATEGORIES, e.g., Office Supplies, Travel, Software, Marketing, Professional Services, Utilities, Meals & Entertainment].

For each expense, provide:
- Category
- Subcategory (if applicable)
- Tax-deductible: Yes/No/Partial
- Notes (if anything looks unusual)

Expenses:
[PASTE EXPENSE LIST: date, vendor, amount, description]
```
**Best for:** Month-end bookkeeping that takes hours done in minutes.

### Prompt 42 — Receipt Data Extraction
```
Extract data from these [NUMBER] receipts and format as a table:
| Date | Vendor | Category | Items | Subtotal | Tax | Total | Payment Method |

Flag any receipts that:
- Might be personal (not business)
- Have unusual amounts
- Are missing critical information

Receipt text/OCR output:
[PASTE RECEIPT DATA]
```
**Best for:** Processing a pile of receipts without manual entry.

### Prompt 43 — Expense Report Generator
```
Generate an expense report for [NAME], [DEPARTMENT], for the period [START DATE] to [END DATE].
Company: [COMPANY NAME]
Approval manager: [MANAGER NAME]

Include:
- Summary table by category
- Individual line items with dates
- Total and per-category subtotals
- Policy compliance notes (flag anything over [AMOUNT] per meal, [AMOUNT] per night hotel)

Expenses:
[PASTE EXPENSE LIST]
```
**Best for:** Generating formatted expense reports ready for manager approval.

---

## 11. Report Generator (Prompts 44–47)

### Prompt 44 — Weekly Business Summary
```
Based on this data, write a weekly business summary for [AUDIENCE: management/team/board].
Period: [DATE RANGE]

Include sections for:
- Key metrics vs. targets
- Highlights and wins
- Issues and risks
- Action items for next week
- One chart suggestion (describe what to visualize)

Raw data/notes:
[PASTE METRICS, NOTES, OR DATA POINTS]
```
**Best for:** Turning raw numbers into a narrative leadership can actually act on.

### Prompt 45 — Client/Project Status Report
```
Create a [WEEKLY/MONTHLY] status report for the [PROJECT NAME] project.
Client: [CLIENT NAME]
Project manager: [NAME]

Sections needed:
- Executive summary (3 sentences)
- Milestone tracker (completed / in progress / upcoming)
- Budget: spent [AMOUNT] of [TOTAL], [ON TRACK/AT RISK]
- Risks and mitigations
- Next period goals

Raw updates:
[PASTE TEAM UPDATES OR NOTES]
```
**Best for:** Professional project updates that take 5 minutes instead of an hour.

### Prompt 46 — Financial Summary from Raw Data
```
Create a financial summary from this data:
Period: [MONTH/QUARTER/YEAR]
Business: [COMPANY NAME]

Calculate and present:
- Revenue summary (by [PRODUCT/SERVICE/CLIENT])
- Expense breakdown by category
- Profit margins
- Month-over-month or quarter-over-quarter trends
- Cash position summary
- 3 key takeaways for the business owner

Data:
[PASTE FINANCIAL DATA: CSV, TABLE, OR RAW NUMBERS]
```
**Best for:** Owner-friendly financial snapshots without waiting for your accountant.

### Prompt 47 — KPI Dashboard Text
```
Generate dashboard commentary for these KPIs:
[LIST KPIS WITH CURRENT VALUES AND TARGETS]

For each KPI:
- Status: 🟢 On Track / 🟡 At Risk / 🔴 Off Track
- One-line explanation of current performance
- Recommended action if not on track

End with a 3-sentence executive summary.
```
**Best for:** Adding context to numbers so dashboards actually drive decisions.

---

## 12. Contract Review (Prompts 48–50)

### Prompt 48 — Contract Red Flag Scanner
```
Review this contract and flag potential issues. I am the [CLIENT/VENDOR/EMPLOYEE] side.
Business context: [BRIEF DESCRIPTION OF THE DEAL]

Flag:
- Unusual or one-sided clauses
- Auto-renewal terms
- Liability and indemnification concerns
- Termination restrictions
- Non-compete or exclusivity clauses
- Missing standard protections
- Vague language that could be exploited

Rate overall risk: Low / Medium / High

Contract:
[PASTE CONTRACT TEXT]

⚠️ Note: This is AI-assisted review, not legal advice. Consult a lawyer for significant contracts.
```
**Best for:** Catching obvious red flags before sending a contract to (expensive) legal review.

### Prompt 49 — Contract Summary for Non-Lawyers
```
Summarize this contract in plain English for a business owner. No legal jargon.

Cover:
1. What are we agreeing to? (2–3 sentences)
2. What do we owe? (money, deliverables, timelines)
3. What do they owe? (money, deliverables, timelines)
4. How long does this last?
5. How can either side get out?
6. What happens if something goes wrong?
7. Anything surprising or unusual?

Contract:
[PASTE CONTRACT TEXT]

⚠️ Note: AI summary — not a substitute for legal review.
```
**Best for:** Understanding what you're actually signing without a law degree.

### Prompt 50 — Contract Clause Generator
```
Draft a [CLAUSE TYPE] clause for a [CONTRACT TYPE: service agreement/NDA/employment contract/vendor agreement].

Context:
- We are: [YOUR COMPANY AND ROLE IN THE CONTRACT]
- The other party: [THEIR ROLE]
- Specific needs: [WHAT YOU WANT THE CLAUSE TO DO]
- Jurisdiction: [COUNTRY/STATE]
- Tone: [STANDARD/PROTECTIVE/BALANCED]

Provide 2 versions: one favoring our side, one balanced.

⚠️ Note: Use as a starting point — have a lawyer review before including in final contracts.
```
**Best for:** Drafting specific clauses when you know what you need but not the legal language.

---

## 💡 Tips for Getting the Best Results

1. **Be specific with brackets** — "Our SaaS product for HR teams" beats "our product"
2. **Paste real data** — The more context you give, the better the output
3. **Iterate** — First output is a draft. Say "make it more concise" or "add more detail about X"
4. **Chain prompts** — Use output from one prompt as input to another
5. **Save your best customized versions** — Build your own prompt library over time

---

*Part of the AI Automation Playbook for SMEs — © Beorns Co*
