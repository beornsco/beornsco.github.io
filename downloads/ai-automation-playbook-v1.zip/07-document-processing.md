# Chapter 7: Document Processing Pipeline

## What This Playbook Does

Invoices. Receipts. Contracts. Purchase orders. Every business drowns in documents that need to be read, understood, and entered somewhere else — a spreadsheet, an accounting tool, a CRM, a filing system.

This playbook shows you how to use AI to extract structured data from unstructured documents. Instead of manually reading each invoice and typing numbers into a spreadsheet, you'll photograph or upload the document, let AI extract the key information, and review the results. What takes 5-10 minutes per document manually takes 30-60 seconds with AI.

**Estimated implementation time:** 3-5 hours
**Expected time savings:** 3-8 hours per week (depending on document volume)
**Difficulty:** Intermediate

---

## Tools You'll Need

### Free Options
- **ChatGPT Plus with image upload** ($20/month — technically paid, but the most accessible option for document processing)
- **Claude with file upload** (free tier handles PDFs and images)
- **Google Docs** — for OCR (upload an image of a document; Google converts it to editable text)
- **A phone camera** — to photograph physical documents

### Paid Options (for higher volume and automation)
- **Nanonets** (from $49/month) — AI document processing, extracts data from invoices/receipts automatically
- **Rossum** (custom pricing) — enterprise-level AI document extraction
- **Dext (formerly Receipt Bank)** (from $24/month) — receipt and invoice scanning for accounting
- **Mindee** (free tier available) — API-based document parsing
- **Microsoft Power Automate + AI Builder** (included in some Microsoft 365 plans) — document processing workflows

**Recommended starting point:** ChatGPT Plus or Claude with file/image upload. You can process most document types by simply uploading a photo or PDF.

---

## Step-by-Step Setup

### Step 1: Identify Your Document Types (20 minutes)

List every type of document your business processes regularly:

| Document Type | Volume per Week | Who Processes It | Where Does Data Go |
|--------------|----------------|-----------------|-------------------|
| Supplier invoices | ~15 | Office manager | Accounting software |
| Expense receipts | ~20 | Various staff | Expense spreadsheet |
| Customer contracts | ~3 | Sales team | CRM |
| Purchase orders | ~8 | Operations | Inventory system |
| Delivery notes | ~10 | Warehouse | Spreadsheet |

Focus on the document types with the highest volume first — that's where you'll save the most time.

### Step 2: Define What Data You Need to Extract (20 minutes)

For each document type, list exactly what information you need. Be specific:

**For invoices:**
- Supplier name
- Invoice number
- Invoice date
- Due date
- Line items (description, quantity, unit price, total)
- Subtotal, tax amount, total
- Payment details (bank account, reference)
- Currency

**For receipts:**
- Vendor name
- Date
- Items purchased (description and price)
- Total amount
- Payment method
- Tax amount
- Category (office supplies, travel, meals, etc.)

**For contracts:**
- Parties involved
- Effective date and end date
- Key terms and obligations
- Payment terms
- Termination clauses
- Renewal terms
- Notable restrictions or conditions

### Step 3: Create Your Extraction Prompts (30 minutes)

Build a prompt for each document type. Here's the key: tell AI exactly what format you want the output in, so you can paste it directly into your spreadsheet or system.

> **Invoice Extraction Prompt:**
>
> I'm uploading an invoice. Please extract the following information and format it exactly as shown:
>
> ```
> Supplier: [company name]
> Invoice Number: [number]
> Invoice Date: [DD/MM/YYYY]
> Due Date: [DD/MM/YYYY]
> Currency: [EUR/USD/GBP etc.]
>
> Line Items:
> 1. [Description] | Qty: [X] | Unit Price: [X.XX] | Total: [X.XX]
> 2. [Description] | Qty: [X] | Unit Price: [X.XX] | Total: [X.XX]
> [continue for all items]
>
> Subtotal: [X.XX]
> Tax ([X]%): [X.XX]
> Total: [X.XX]
>
> Payment Details:
> Bank: [name]
> Account/IBAN: [number]
> Reference: [payment reference]
> ```
>
> Rules:
> - If a field is not visible on the invoice, write "NOT FOUND"
> - Use the date format DD/MM/YYYY
> - Include the currency symbol with all amounts
> - If there are multiple tax rates, list each separately
> - Double-check that line item totals add up to the subtotal

> **Receipt Extraction Prompt:**
>
> I'm uploading a receipt or expense document. Please extract:
>
> ```
> Vendor: [name]
> Date: [DD/MM/YYYY]
> Category: [suggest one: Office Supplies / Travel / Meals & Entertainment / Software / Equipment / Marketing / Other]
>
> Items:
> 1. [Description] — [amount]
> 2. [Description] — [amount]
>
> Subtotal: [X.XX]
> Tax: [X.XX]
> Total: [X.XX]
> Payment Method: [Cash/Card/Bank Transfer — if visible]
> ```
>
> If the receipt is partially unreadable, extract what you can and mark unclear items as "[UNCLEAR]".

> **Contract Review Prompt:**
>
> I'm uploading a contract. Please provide a structured summary:
>
> ```
> PARTIES:
> Party A: [name and role]
> Party B: [name and role]
>
> KEY DATES:
> Effective Date: [date]
> End Date: [date]
> Renewal: [auto-renew / manual / N/A — with terms]
>
> FINANCIAL TERMS:
> Total Value: [amount]
> Payment Schedule: [terms]
> Late Payment: [penalties if mentioned]
>
> KEY OBLIGATIONS:
> Party A must: [list]
> Party B must: [list]
>
> TERMINATION:
> Notice Period: [X days/months]
> Termination Conditions: [list]
> Early Termination Penalties: [if any]
>
> RED FLAGS / NOTABLE CLAUSES:
> - [List anything unusual, one-sided, or that needs attention]
>
> MISSING / UNCLEAR:
> - [List any expected clauses that are missing or ambiguous]
> ```
>
> Important: You are helping me understand this contract. This is NOT legal advice. Flag anything significant, but remind me to consult a lawyer for anything I plan to act on.

### Step 4: Process Your First Batch (1-2 hours)

Take 10 documents and process them through your prompts:

**For photos/scans:**
1. Take a clear photo of the document (good lighting, no shadows, all text visible)
2. Upload to ChatGPT or Claude
3. Paste your extraction prompt
4. Review the output
5. Copy data to your spreadsheet/system

**For PDF documents:**
1. Upload the PDF directly to ChatGPT or Claude
2. Paste your extraction prompt
3. Review and transfer

**For each document, track:**
- Processing time (AI extraction + your review)
- Accuracy (did it get the numbers right?)
- Issues (what did it miss or get wrong?)

### Step 5: Create a Spreadsheet-Ready Output Format (30 minutes)

If you're entering data into a spreadsheet, have AI output in a format you can paste directly:

> **Spreadsheet-Ready Invoice Prompt:**
>
> I'm uploading an invoice. Extract the data and format it as a single tab-separated row that I can paste into a spreadsheet with these columns:
>
> Date | Supplier | Invoice# | Description | Subtotal | Tax | Total | Due Date | Status
>
> Use tab characters between fields. Date format: DD/MM/YYYY. Use "Unpaid" for status.
>
> If there are multiple line items, create one row per line item with the invoice details repeated.

This lets you literally copy the AI output and paste it into your spreadsheet — no manual data entry at all.

### Step 6: Build Your Processing Routine (20 minutes)

Set up a regular cadence for document processing:

**Daily routine (for high-volume businesses):**
- Collect all documents received today (email attachments, physical mail scanned, receipts from team)
- Process in a batch: upload all to AI, extract data, review
- Enter into your systems
- File the originals (digital or physical)

**Weekly routine (for lower volume):**
- Designate one time per week for document processing (e.g., Friday afternoon)
- Process the week's accumulated documents in one batch
- Enter data and file

**The physical document workflow:**
1. Receive document
2. Photograph or scan immediately (don't let them pile up)
3. Drop into a "To Process" folder (Google Drive, Dropbox, or physical inbox)
4. During processing time, run through AI extraction
5. Move to "Processed" folder after data entry

### Step 7: Verify and Build Confidence (Ongoing)

For the first month, verify every AI extraction against the source document. Track accuracy:

- **Invoice amounts:** Does the AI total match the actual total?
- **Dates:** Are dates correctly extracted (watch for US vs. EU date formats)?
- **Names:** Are company names spelled correctly?
- **Line items:** Are all items captured?

Most users find AI achieves 90-95% accuracy on clean, clear documents. The remaining 5-10% usually involves:
- Handwritten text
- Poor image quality
- Unusual document layouts
- Multiple languages on one document

After a month of verification, you'll know which document types AI handles well (reduce your review time) and which need more careful checking.

---

## Example: Before and After

### Before (Manual Processing):
Office manager receives 15 supplier invoices per week by email. Opens each PDF, reads the details, types them into accounting software. Each invoice takes 5-8 minutes. Total: ~2 hours per week. Often makes typos that cause reconciliation issues later.

### After (AI-Assisted Processing):
Office manager downloads all 15 PDFs. Uploads them to ChatGPT one by one with the extraction prompt. Reviews each extraction (30-60 seconds per invoice — just checking the numbers match). Copies the formatted data into accounting software. Total: ~30-40 minutes per week. Fewer data entry errors.

---

## Expected Results

| Metric | Before | After |
|--------|--------|-------|
| Time per invoice/receipt | 5-8 minutes | 1-2 minutes |
| Time per contract review | 30-60 minutes | 10-15 minutes |
| Data entry errors | 2-5% | Under 1% |
| Weekly time savings (15 invoices + 20 receipts) | — | 3-5 hours |
| Document processing backlog | Growing | Cleared weekly |

---

## Common Pitfalls and How to Avoid Them

### Pitfall 1: Poor Image Quality Ruins Extraction
A blurry, dark, or partially cut-off photo will produce garbage output. **Prevention:** Take photos in good lighting, straight-on (not at an angle), with all text visible. For important documents, use a scanner app like Adobe Scan or Microsoft Lens — these auto-correct perspective and enhance contrast.

### Pitfall 2: Trusting Numbers Without Verification
AI is good at reading documents, but it's not infallible. A misread "8" as "3" on an invoice could cost you money. **Prevention:** Always verify totals for the first month. After that, spot-check 20% of documents. For high-value documents (over €1,000), always verify.

### Pitfall 3: Using AI for Legally Sensitive Documents Without Professional Review
AI can summarize contracts and flag unusual clauses, but it's not a lawyer. **Prevention:** Use AI to create a first-pass summary that saves time, but have a real lawyer review anything you plan to sign. Add a note to your contract prompt: "This is for understanding purposes only — not legal advice."

### Pitfall 4: Not Standardizing Your Output Format
If every extraction looks different, you'll spend time reformatting instead of saving time. **Prevention:** Define your output format precisely in the prompt (Step 3 and Step 5). Use the same format every time.

### Pitfall 5: Processing One Document at a Time When You Could Batch
Uploading one document, extracting, then uploading the next is slow. **Prevention:** Some AI tools let you process multiple pages in one session. Upload all invoices at once and say "Process all invoices on the following pages, providing the extraction for each one separately."

---

## Handling Different Document Languages

If your business receives documents in multiple languages (common in the EU), AI handles this well:

> **Multi-Language Extraction Prompt:**
>
> I'm uploading a document that may be in [Dutch/French/German/English]. Please:
> 1. Identify the language of the document
> 2. Extract all data fields into English
> 3. Keep proper nouns (company names, addresses) in their original language
> 4. Convert any dates to DD/MM/YYYY format
> 5. Keep amounts in their original currency

---

## Scaling Up: Automated Document Processing

Once manual AI-assisted processing is working, consider these next steps:

- **Email forwarding rule** — automatically forward invoices from known suppliers to a processing inbox
- **Zapier + AI** — new email attachment → AI extraction → data added to spreadsheet/accounting tool
- **Dext or Nanonets** — dedicated document processing that connects to accounting software (Xero, QuickBooks, etc.)
- **Custom automation** — for high volume, build a simple script that processes a folder of PDFs through an AI API

> **Automation Architecture Example:**
>
> 1. Supplier sends invoice by email
> 2. Email rule forwards to "invoices@yourcompany.com"
> 3. Zapier triggers on new email
> 4. Attachment is uploaded to AI extraction (via API)
> 5. Extracted data is added to a Google Sheet
> 6. Office manager reviews the sheet once daily
> 7. Approved entries are synced to accounting software

This turns a 2-hour weekly task into a 15-minute daily review.

---

## Quick-Start Checklist

- [ ] List all document types you process regularly
- [ ] Define exactly what data you need from each type
- [ ] Create extraction prompts for your top 2-3 document types
- [ ] Process 10 documents as a test
- [ ] Verify accuracy against source documents
- [ ] Create spreadsheet-ready output formats
- [ ] Set up a processing routine (daily or weekly)
- [ ] Train anyone who handles documents on the new process
- [ ] Track time savings for the first month
- [ ] After 1 month, reduce verification to spot-checks for high-accuracy document types
- [ ] Consider scaling to automated processing if volume justifies it
