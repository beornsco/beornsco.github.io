# Chapter 16: Measuring and Improving Your Automations

## What Gets Measured Gets Improved

You've built automations. They're running. But are they actually working?

This chapter gives you a simple framework for measuring the impact of your automations, knowing when to improve them, and deciding when to move on to the next one.

---

## The Four KPIs That Matter

You don't need a dashboard with 50 metrics. Track these four for each automation:

### 1. Time Saved Per Week
The most tangible metric. Before you automate, measure how long the manual process takes. After automation, measure what's left.

**How to calculate:**
> Manual time per occurrence × occurrences per week = weekly time cost
>
> Example: Writing customer emails manually takes 8 minutes each. You send ~30 per week.
> Manual: 8 min × 30 = 240 minutes = 4 hours/week
> With AI assistance: 2 min × 30 = 60 minutes = 1 hour/week
> **Time saved: 3 hours/week**

### 2. Cost Saved Per Month
Convert time saved into money. This is the number that gets leadership buy-in.

**How to calculate:**
> Hours saved per week × hourly labor cost × 4.33 weeks = monthly savings
>
> Example: 3 hours/week × €35/hour × 4.33 = €455/month
> Minus tool costs: €455 - €20 (ChatGPT Plus) = **€435 net savings/month**

### 3. Quality Score
Is the automated output as good as (or better than) manual? Rate on a simple 1-5 scale:

| Score | Meaning |
|-------|---------|
| 1 | Unusable — needs complete rework |
| 2 | Poor — needs significant editing |
| 3 | Acceptable — needs minor tweaks |
| 4 | Good — ready to use with quick review |
| 5 | Excellent — better than manual output |

**Target: 3 or above.** If you're consistently at 2 or below, the automation needs rework or the use case might not be suitable for AI.

### 4. Adoption Rate
What percentage of your team actually uses the automation?

**How to calculate:**
> Team members using it regularly ÷ team members who could use it × 100
>
> Example: 6 out of 8 team members use the email template system = 75% adoption

**Target: 70% or above.** Below 50% means there's a friction problem — the tool is too hard to use, people don't trust it, or they weren't trained properly.

---

## The Measurement Cadence

### Week 1-2: Baseline
Before launching an automation, document the current state:
- How long does the process take manually?
- How often does it happen?
- Who does it?
- What's the current quality level?

### Week 3-4: Early Results
Two weeks after launching:
- Is anyone using it?
- What's the initial time savings?
- What complaints or issues have come up?
- What needs tweaking?

### Month 2: Real Assessment
After a full month of use:
- Calculate actual time and cost savings
- Score quality
- Measure adoption
- Decide: keep, improve, or kill

### Quarterly: Portfolio Review
Every 3 months, review all your automations together:
- Which ones deliver the most value?
- Which ones are underperforming?
- Where should you invest next?

---

## The Improve-or-Move-On Decision

After measuring, you'll face a decision for each automation. Use this framework:

### Keep and Scale (High Impact, High Adoption)
**Signs:**
- Time savings exceed expectations
- Team uses it without reminders
- Quality score is 4-5
- People ask to expand it to other areas

**Action:** Document it as an SOP, train new hires on it, look for ways to expand.

### Improve (High Potential, Fixable Issues)
**Signs:**
- Good time savings but quality needs work
- Team uses it but complains about specific things
- Quality score is 2-3 but trending up
- The underlying process is clearly automatable

**Action:** Spend 2-4 hours refining prompts, adding templates, or improving the workflow. Set a 2-week deadline for reassessment.

### Pivot (Wrong Approach, Right Problem)
**Signs:**
- The problem is real but your solution isn't working
- Low adoption despite training
- Quality score stuck at 2
- You keep manually overriding the automation

**Action:** Try a different tool or approach. Maybe the email drafting automation works better with Claude instead of ChatGPT. Maybe you need a specialized tool instead of general AI.

### Kill (Low Impact or Wrong Problem)
**Signs:**
- Time savings are minimal (< 30 minutes/week)
- Nobody uses it even after training
- Quality score is consistently 1-2
- The process doesn't happen often enough to justify automation

**Action:** Turn it off. Remove the tools. Move your energy to the next opportunity. Killing a bad automation is a win — it frees up resources.

---

## Common Measurement Mistakes

### 1. Not Measuring the Baseline
If you don't know how long something took manually, you can't prove automation helped. Always measure before you automate.

### 2. Only Measuring Time
Time saved is important, but quality and consistency matter too. An automation that saves 2 hours but produces worse output isn't a win.

### 3. Measuring Too Early
AI automations improve as you refine prompts and workflows. Don't judge results after 3 days. Give it at least 2 weeks of real use.

### 4. Ignoring Maintenance Cost
Every automation needs occasional attention — prompts need updating, tools change their APIs, new edge cases appear. Factor in 30 minutes/month per automation for maintenance.

### 5. Not Asking Users
The best measurement is often qualitative. Ask your team: "Does this make your job easier?" A confident "yes" is worth more than a spreadsheet.

---

## The Continuous Improvement Loop

Automation isn't "set and forget." Use this monthly loop:

```
1. MEASURE
   → Check KPIs for each automation
   → Update your project tracker

2. IDENTIFY
   → Which automations underperform?
   → Where are people working around the automation?
   → What new processes could be automated?

3. IMPROVE
   → Refine prompts (most common improvement)
   → Update templates with real examples
   → Fix edge cases people report
   → Simplify steps that cause friction

4. EXPAND
   → Apply successful patterns to new areas
   → Train new team members
   → Increase automation depth (AI-assisted → fully automated)

5. REPEAT
   → Monthly for active automations
   → Quarterly for portfolio review
```

---

## Your Automation Scorecard

Use this template to track all your automations at a glance:

| Automation | Time Saved/Week | Monthly Value | Quality (1-5) | Adoption % | Status |
|-----------|----------------|---------------|---------------|-----------|--------|
| Customer email drafts | 3 hrs | €435 | 4 | 75% | ✅ Keep |
| Meeting notes | 2 hrs | €290 | 4 | 90% | ✅ Keep |
| Social media posts | 1.5 hrs | €218 | 3 | 60% | 🔧 Improve |
| Expense categorization | 1 hr | €145 | 3 | 50% | 🔧 Improve |
| Lead scoring | 0.5 hrs | €73 | 2 | 30% | 🔄 Pivot |

**Total: 8 hours/week saved = €1,161/month in value from 5 automations.**

---

## The Compound Effect

Here's the math that makes automation transformative:

- Month 1: 1 automation → 3 hours/week saved → €435/month
- Month 2: 3 automations → 7 hours/week saved → €1,015/month
- Month 3: 5 automations → 12 hours/week saved → €1,740/month
- Month 6: 8 automations → 18 hours/week saved → €2,610/month

That's over €30,000/year in recovered time from about €50-150/month in tools.

The key: **start small, measure everything, improve what works, kill what doesn't.**

---

## Final Thoughts

Automation is a practice, not a project. The businesses that get the most from AI aren't the ones with the best technology — they're the ones that systematically measure, improve, and expand.

Your first automation won't be perfect. Your fifth will be good. Your tenth will feel like magic.

Start with Chapter 3. Pick the playbook closest to your biggest pain point. Measure the baseline today. Implement this week. Measure again in two weeks.

Then do it again.

---

*Thank you for reading the AI Automation Playbook for SMEs. For more resources, visit beornsco.github.io*

*Built by Beorns Co — practical AI tools for real businesses.*
